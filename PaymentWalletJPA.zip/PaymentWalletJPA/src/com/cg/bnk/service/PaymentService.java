package com.cg.bnk.service;

import java.util.ArrayList;

import com.cg.bnk.bean.Payment;
import com.cg.bnk.bean.PaymentPassword;
import com.cg.bnk.bean.Transaction;
import com.cg.bnk.bean.WalletMoney;
import com.cg.bnk.exception.BankException;

public interface PaymentService {

	
	public Payment getPayment(int account)throws BankException;
	
	public Payment addAccount(Payment pay)throws BankException;
	
	public Payment toAddMoney(int bal,int account)throws BankException;
	
	public Payment toTransferMoney(int bal,int account)throws BankException;
	
	//public Payment toTransferFund(int acc1, int acc2, double bal)throws BankException;
	
	public Payment checkAccount(int account,String ifsc,String name,String email)throws BankException;
	
	public PaymentPassword addPasswordAccount(PaymentPassword pass)throws BankException;
	
	//public Transaction addDetail(Transaction trans)throws BankException;
	
	//public Transaction getDetail(int id)throws BankException;
	public ArrayList<Transaction> transactionHistory(int accountNo) throws BankException;
	
	public PaymentPassword getPasswordEmail(String password)throws BankException;

	public WalletMoney addWalletBalance(WalletMoney money)throws BankException;
	
	public WalletMoney getWallet(int account) throws BankException;
	//public WalletMoney getWalletinfo(int account)throws BankException;
	public ArrayList<Integer> getWalletinfo(int account) throws BankException;
}
