package com.cg.bnk.bean;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="transaction_JPA")
public class Transaction {
	
	@Id
	@Column(name="transactionid",length=20)
//	@GeneratedValue(strategy=GenerationType.AUTO)
//	@SequenceGenerator(name="mySeq",sequenceName="trans_seq",allocationSize=10000)
	int transactionId;
	
	@Column(name="accountno",length=10)
	int accountNo;
	
	@Column(name="amount",length=10)
	int amount;
	
	@Column(name="transactiondate")
	Date transactionDate;
	//LocalDate time;
//	public int getTransacId() {
//		return transacId;
//	}
	public void setTransactionId(int transacId) {
		this.transactionId = transacId;
	}
	public int getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}

	public int getTransactionId() {
		// TODO Auto-generated method stub
		return transactionId;
	}
	public Date getTransactionDate() {
		return transactionDate;
	}
	public void setTransactionDate(Date transactionDate) {
		this.transactionDate = transactionDate;
	}
	@Override
	public String toString() {
		return "\nTransaction Detail \nTransaction Id=" + transactionId + " \nAccount No=" + accountNo + " \nAmount=" + amount
				+ " \nTransaction Date=" + transactionDate + "\n";
	}
	public Transaction(int transactionId, int accountNo, int amount, Date transactionDate) {
		super();
		this.transactionId = transactionId;
		this.accountNo = accountNo;
		this.amount = amount;
		this.transactionDate = transactionDate;
	}
	public Transaction() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
}
