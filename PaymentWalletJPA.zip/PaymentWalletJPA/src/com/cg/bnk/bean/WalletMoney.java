package com.cg.bnk.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="wallet_JPA")
public class WalletMoney {
	@Id
	@Column(name="serial_no")
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="mySeq")//generating in sequence
	@SequenceGenerator(name="mySeq",sequenceName="contact_seq",allocationSize=1)
	private int no;
	
	@Column(name="account_no")
	private int account;
	
	@Column(name="balance")
	private int balance;

	public int getAccount() {
		return account;
	}

	public void setAccount(int account) {
		this.account = account;
	}

	public int getBalance() {
		return balance;
	}

	public void setBalance(int balance) {
		this.balance = balance;
	}

	@Override
	public String toString() {
		return "WalletMoney \nbalance=" + balance ;
	}

	public WalletMoney(int account, int balance) {
		super();
		this.account = account;
		this.balance = balance;
	}

	public WalletMoney() {
		super();
		// TODO Auto-generated constructor stub
	}

	
}
