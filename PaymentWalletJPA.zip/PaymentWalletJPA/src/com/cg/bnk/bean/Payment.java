package com.cg.bnk.bean;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 * Hello world!
 *
 */
@Entity
@Table(name="bank_JPA")
public class Payment 
{
	@Id
	@Column(name="account",length=10)	
	private int account;
	
	@Column(name="name",length=30)
	private String name;
	
	@Column(name="ifsc",length=10)
	private String ifsc;
	
	@Column(name="mobile",length=10)
	private String mobile;
	
	@Column(name="email",length=40)
	private String email;
	
	@Column(name="bal",length=10)
	private int bal;
	
//	@OneToMany(targetEntity=Transaction.class)
//	private List transactionList;
	
//	
//	public List getTransactionList() {
//		return transactionList;
//	}
//	public void setTransactionList(List transactionList) {
//		this.transactionList = transactionList;
//	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAccount() {
		return account;
	}
	public void setAccount(int account) {
		this.account = account;
	}
	public String getIfsc() {
		return ifsc;
	}
	public void setIfsc(String ifsc) {
		this.ifsc = ifsc;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}

	
	public int getBal() {
		return bal;
	}
	public void setBal(int bal) {
		this.bal = bal;
	}

	
	@Override
	public String toString() {
		return "Payment [name=" + name + ", account=" + account + ", ifsc=" + ifsc + ", mobile=" + mobile + ", email="
				+ email + ", bal=" + bal + "]";
	}
	
	
	
	public Payment(String name, int account, String ifsc, String mobile, String email, int bal) {
		super();
		this.name = name;
		this.account = account;
		this.ifsc = ifsc;
		this.mobile = mobile;
		this.email = email;
		this.bal = bal;
	}
	public Payment() {
		
	}
}
