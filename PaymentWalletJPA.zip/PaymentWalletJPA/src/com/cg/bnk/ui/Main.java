package com.cg.bnk.ui;

import java.sql.Date;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;
import com.cg.bnk.bean.Payment;
import com.cg.bnk.bean.PaymentPassword;
import com.cg.bnk.bean.Transaction;
import com.cg.bnk.bean.WalletMoney;
import com.cg.bnk.exception.BankException;
import com.cg.bnk.service.PaymentService;
import com.cg.bnk.service.PaymentServiceImpl;
import com.cg.bnk.service.Validator;

public class Main {

	public static void main(String[] args) 
	{
		Transaction transac = new Transaction();
		PaymentService service = new PaymentServiceImpl();
		Validator validator = new Validator();
		Payment pay = new Payment();
		PaymentPassword pass = new PaymentPassword();
		WalletMoney wallet = new WalletMoney();
		int n;
		
			do
			{	
				Scanner sc = new Scanner(System.in);
				//System.out.println("\n1.Registeration\n2.Add account\n3.To Add Money \n4.To transfer money\n5.Show details \n6.Show Balance \n7.Exit ");
				System.out.println("\n1.New register\n2.Already Existing Account \n3.Exit");
				System.out.println("Enter option : ");
				
				n = sc.nextInt();
				
				switch(n) {
				
				case 2:
				{
					System.out.println("Enter Email ID : ");
					String email1 = sc.next();
					//System.out.println(email1);
					System.out.println("Enter password : ");
					String password = sc.next();
//				System.out.println("Enter confirm password: ");
//				String password1 = sc.next();
					int n1;
					PaymentPassword pass1;
					try {
						pass1 = service.getPasswordEmail(email1);
					//System.out.println(pass1);
					if(pass1.getPassword().equals(password) && pass1.getEmail().equals(email1))
					{
//					
						do{System.out.println("\n1.Link account \n2.To Add Money in Wallet \n3.To transfer money \n4.Show details \n5.Show Balance \n6.Show Transaction Detail");
						System.out.println("Enter : ");
						n1 = sc.nextInt();
						 	switch(n1) {
						 	case 1:
						 	{
						 		try {
									System.out.println("Enter Name : ");
									String name1 = sc.next();
									
									System.out.println("Enter Mobile number : ");
									String mobile1 = sc.next();
									if(validator.validateMobile(mobile1)==false)
										throw new BankException("Enter ten digit number");
									
									System.out.println("Enter Email ID : ");
									String email = sc.next();
									
									
									System.out.println("Enter IFSC code : ");
									String ifsc1 = sc.next();
									
									System.out.println("Enter Account number : ");
									int account1 = sc.nextInt();
									if(validator.validateAccount(Integer.toString(account1))==false)
										throw new BankException("Invalid Account number");
						
									pay.setName(name1);
									pay.setMobile(mobile1);
									pay.setEmail(email);
									pay.setAccount(account1);
									pay.setIfsc(ifsc1);
									pay = service.checkAccount(account1, ifsc1, name1, email);
									
									if(pay.getAccount()==account1 && pay.getEmail().equals(email) && pay.getIfsc().equals(ifsc1) && pay.getName().equalsIgnoreCase(name1))
									{
										System.out.println("Linked");
									}
									else
									{
										System.out.println("not linked");
									}
									}
									catch(BankException e)
									{
										System.out.println(e.getMessage());
									}
									break;
						 	}
									
						 	case 2:
						 		{
						 			try
									{
						 			System.out.println("Enter your account number to add money : ");
									int accoun = sc.nextInt();
									System.out.println("Enter the amount to add money : ");
									int bal = sc.nextInt();
									Payment pay1 = service.getPayment(accoun);
									if(pay1.getBal()<bal==true) 
										throw new BankException("Amount is greater than current balance") ;
									
										pay = service.toAddMoney(bal, accoun);
										
										/*Random ran = new Random();
										int a = ran.nextInt(90000);
										transac.setAccountNo(accoun);
										transac.setTransactionId(a);
										transac.setAmount((int) bal);
										transac.setTransactionDate(Date.valueOf(LocalDate.now()));
										service.addDetail(transac);
										*/
										
										wallet.setAccount(accoun);
										wallet.setBalance(bal);
										wallet = service.addWalletBalance(wallet);
										
										
										//System.out.println("Your Transaction ID is : "+a);
									}catch(BankException e)
									{
										System.out.println(e.getMessage());
									}
									break;
						 		}
						 		
							case 3:
								{
									try {
									System.out.println("Enter your account number : ");
									int a1 = sc.nextInt();
									System.out.println("Enter sender account number : ");
									int a2 = sc.nextInt();
									System.out.println("Balance : ");
									int b = sc.nextInt();
									//pay = service.toTransferFund(a1, a2, b);
									pay = service.toAddMoney(b, a1);
									pay = service.toTransferMoney(b, a2);
									
									//Random ran = new Random();
								//	int a = ran.nextInt(90000000)+10000000;
									//transac.setAccountNo(a1);
									//transac.setTransactionId(a);
									//transac.setAmount((int) b);
									//transac.setTransactionDate(Date.valueOf(LocalDate.now()));
									
									//transac = service.addDetail(transac);
									//System.out.println("Your Transaction ID is : "+a);
									} catch (BankException e) {
										// TODO Auto-generated catch block
										e.printStackTrace();
									}
									break;
								}
							case 4:
								{
									try {
									System.out.println("Enter account number : ");
									int accoun = sc.nextInt();
									if(validator.validateAccount(Integer.toString(accoun))==false)
										throw new BankException("Invalid account number");
									else 
									{	
										pay = service.getPayment(accoun);
									
									System.out.println("Account : "+pay.getAccount());
									System.out.println("Name : "+pay.getName());
									System.out.println("IFSC number : "+pay.getIfsc());
									System.out.println("Mobile number : "+pay.getMobile());
									System.out.println("Email : "+pay.getEmail());
									
									//System.out.println(wallet);
								    ArrayList<Integer> b = service.getWalletinfo(accoun);
									System.out.println("Balance : "+b);
									}
									}catch(BankException e)
									{
										System.out.println(e.getMessage());
									}
									break;
								}
							case 5:
								{
									try
									{
									System.out.println("Enter account number : ");
									int accoun = sc.nextInt();
									if(validator.validateAccount(Integer.toString(accoun))==false)
										throw new BankException("Invalid account number");
									else 
									{	
										pay = service.getPayment(accoun);
										System.out.println("Balance : "+pay.getBal());
									}
									}catch(BankException e)
									{
										System.out.println(e.getMessage());
									}
									break;
									
								}
							case 6:
							{
								System.out.println("Enter Account No : ");
								int accountNo = sc.nextInt();
								
								try {
									ArrayList<Transaction>t = service.transactionHistory(accountNo);
//								
								} catch (BankException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}
								
							}
						 	}
						}while(n1!=5);
				
					}
					}//catch (NullPointerException e1) {
//						// TODO Auto-generated catch block
//						System.out.println("account does not exists");
//						System.exit(0);
//					}
					catch (BankException e1) {
					// TODO Auto-generated catch block
					System.out.println("account does not exists");
					System.exit(0);
				}
					break;
				}
				case 1:
				{
					try {
					System.out.println("Enter Email : ");
					String email = sc.next();
					System.out.println("Enter Password : ");
					String passw = sc.next();
					
					pass.setEmail(email);
					pass.setPassword(passw);
					
					pass = service.addPasswordAccount(pass);
					//System.out.println("Added"+pass.getPassword());
					} catch (BankException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				break;
				}
				case 3: 
				{
					System.exit(0);
					
				}
				
					
				}
				//sc.close();
				
			}while(n!=3);
		
		
	}
}
