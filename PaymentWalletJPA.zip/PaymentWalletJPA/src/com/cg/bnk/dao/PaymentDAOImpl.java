package com.cg.bnk.dao;


import java.sql.Date;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Random;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import com.cg.bnk.bean.Payment;
import com.cg.bnk.bean.PaymentPassword;
import com.cg.bnk.bean.Transaction;
import com.cg.bnk.bean.WalletMoney;
import com.cg.bnk.exception.BankException;
import com.cg.bnk.util.JPAUtil;

public class PaymentDAOImpl implements PaymentDAO{
	
	EntityManager em = null;
	EntityTransaction tran = null;
	public PaymentDAOImpl() {
		em = JPAUtil.getEntityManager();
		tran = em.getTransaction();
}
	Payment pay = new Payment();
	
	PaymentPassword pass = new PaymentPassword();
	
	Transaction trans = new Transaction();
	
	WalletMoney money = new WalletMoney();
	
	public Payment getPayment(int account) {
	pay = em.find(Payment.class, account);	
		return pay ;
	
	}
	
	@Override
	public WalletMoney getWallet(int account) throws BankException {
		// TODO Auto-generated method stub
		money = em.find(WalletMoney.class, account);
		return money;
	}
	
	
	public Payment addAccount(Payment pay){
		tran.begin();
		em.persist(pay);
		tran.commit();
	return pay;
	}
	
	public Payment toAddMoney(int bal, int account, int transacAmount) throws BankException{
		pay = em.find(Payment.class, account);
		pay.setBal(bal);
		tran.begin();
		em.merge(pay);
		tran.commit();
		
		addDetail(account, transacAmount);
		return pay;	
	}
	
//	@Override
//	public WalletMoney getWalletinfo(int account) throws BankException {
//		// TODO Auto-generated method stub
//		
//		money = em.find(WalletMoney.class, account);
//		money.setBalance(money.getBalance());
////		tran.begin();
////		em.merge(money);
////		tran.commit();
//		System.out.println(money.getBalance());
//		System.out.println(money);
//		return money;
//	}
	
//	@Override
//	public WalletMoney getWalletinfo(int account,int bal) throws BankException {
//		// TODO Auto-generated method stub
//		money = em.find(WalletMoney.class, account);
//		money.setBalance(bal);
//		tran.begin();
//		em.merge(money)
//		return null;
//	}

	

	public Payment toTransferMoney(int bal, int account, int transacAmount) throws BankException {
		pay = em.find(Payment.class, account);
		pay.setBal(bal);
		tran.begin();
		em.merge(pay);
		tran.commit();
		
		addDetail(account, transacAmount);
		return pay;
	}
	
	public Payment checkAccount(int acco,String ifsc,String name,String email) {
		
		String qry = "Select b from Payment b where b.account = :acco and b.ifsc=:ifsc and b.name=:name and b.email=:email";
		//String qry = "Select b from Payment b where b.account = :acco";
		TypedQuery<Payment>tq=em.createQuery(qry,Payment.class);
		tq.setParameter("acco", acco);
		tq.setParameter("ifsc", ifsc);
		tq.setParameter("name", name);
		tq.setParameter("email", email);
		return pay ;
	}
	
	public PaymentPassword addPasswordAccount(PaymentPassword pass) {
		tran.begin();
		em.persist(pass);
		tran.commit();
		return pass;
}
	
	public PaymentPassword getPasswordEmail(String email)
	{
		pass=em.find(PaymentPassword.class, email);
		
		return pass ;
		
	}
	
	
	public void addDetail(int acc,int bal) throws BankException {
		Transaction trans1 = new Transaction();
		Random ran = new Random();
		int a = ran.nextInt(90000);
		trans1.setAccountNo(acc);
		trans1.setTransactionId(a);
		trans1.setAmount((int) bal);
		trans1.setTransactionDate(Date.valueOf(LocalDate.now()));
		
		tran.begin();
		em.persist(trans1);
		tran.commit();
		System.out.println("Tansaction id:"+a );
	}
	
	public ArrayList<Transaction> transactionHistory(int accountNo) throws BankException {
		String st="Select tran from Transaction tran where tran.accountNo= :acc";
		TypedQuery<Transaction>tq= em.createQuery(st,Transaction.class);
		tq.setParameter("acc", accountNo);
		ArrayList<Transaction>list=(ArrayList<Transaction>) tq.getResultList();
		System.out.println(list);
		return list;
	}

	public WalletMoney addWalletBalance(WalletMoney money) throws BankException {
		tran.begin();
		em.persist(money);
		tran.commit();
		return money;
		
	}
	@Override
	public ArrayList<Integer> getWalletinfo(int account) throws BankException {
		// TODO Auto-generated method stub
		String st="Select SUM(wallet.balance) from WalletMoney wallet where wallet.account= :acc";
		Query query  = em.createQuery(st);
		query.setParameter("acc", account);
//		WalletMoney money=tq.getSingleResult();
//		System.out.println(money);
//		return money;
//		int balance = (int) query.getSingleResult();
		ArrayList<Integer> blist =(ArrayList<Integer>) query.getResultList();
		//System.out.println("Wallet Money \nBalance :"+blist);
		return blist;
	}
	
}
