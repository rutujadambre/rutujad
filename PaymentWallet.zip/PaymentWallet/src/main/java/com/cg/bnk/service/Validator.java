package com.cg.bnk.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

//
//import java.util.regex.Pattern;
//
public class Validator {
//	
//	public boolean validateAccount(int account)
//	{
//		if(account==null)
//			throw new NullPointerException();
//		boolean flag = Pattern.matches("[0-9]{4}", account);
//		if(flag)
//			return true;
//		else 
//			return false;
//	}
	
	

	public boolean validateAccount(String acc) {
		// TODO Auto-generated method stub
		if(acc.isEmpty())
			throw new NullPointerException();
		boolean flag = Pattern.matches("[0-9]{4}", acc);
		if(flag)
			return true;
		else 
			return false;
	}
	
	
	public boolean validateMobile(String mobile)
	{
		if(mobile==null)
			throw new NullPointerException();
		Pattern pat = Pattern.compile("[0-9]{10}");
		Matcher mat = pat.matcher(mobile);
		if(mat.matches())
			return true;
		else
			return false;
	}
}
