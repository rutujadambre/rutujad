package com.cg.bnk.database;

import java.util.HashMap;
import java.util.Map;

import com.cg.bnk.bean.Payment;

public class BankDatabase {

	private static Map<Integer,Payment> payments = new HashMap<Integer,Payment>();
	static {
		// TODO Auto-generated method stub
		
		payments.put(1011, new Payment("rutuja",1011,"AD1223N","9028449634","rutujadambre9@gmail.com",50000.0));
		payments.put(1015, new Payment("goku",1015,"DF1236H","1236547895","gfkgjkf@gmail.com",6000000.0));
		payments.put(1012, new Payment("naruto",1012,"DF1236J","123654734","vdgfgr@gmail.com",3450000.0));
		payments.put(1013, new Payment("neha",1013,"DF1236H","1236547895","gfkgjkf@gmail.com",6450000.0));
		payments.put(1016, new Payment("roham",1016,"DF1236H","1236547895","gfkgjkf@gmail.com",7550000.0));
		
	}
	
	public Payment getPayment(int account) {
		// TODO Auto-generated method stub
		Payment pay = payments.get(account);
		return pay ;
	
	}
	public Payment addAccount(Payment pay){
		// TODO Auto-generated method stub
		payments.put(pay.getAccount(), pay);
		return pay;
	}
	
	public Payment toAddMoney(double bal, int account) {
		// TODO Auto-generated method stub
		Payment pay = payments.get(account);
		double balance = pay.getBal();
		double newbal = balance - bal;
		pay.setBal(newbal);;
		return pay;
	}
	
	public Payment toTransferFund(int acc1, int acc2, double bal) {
		// TODO Auto-generated method stub
		Payment pay1 = payments.get(acc1);
		Payment pay2 = payments.get(acc2);
		double bal1 = pay1.getBal();
		double bal2 = pay2.getBal();
		pay1.setBal(bal1-bal);
		pay2.setBal(bal2+bal);
		return pay1;

	}
//	@Override
//	public Payment checkAccount(int account) {
//		// TODO Auto-generated method stub
//		
//		 Set<Integer> keys = payments.keySet(); 
//		 if(payments.containsKey(keys))
//			 return true;
//		 else
//			 return false;
//					 
//		
//	}
//	
//	@Override
//	public Payment checkAccount(Payment pay) {
//		// TODO Auto-generated method stub
//		 payments.keySet(); 
//		 return null;
//	}
//	@Override
//	public Payment checkAccount(int account) {
//		// TODO Auto-generated method stub
//		Payment pay = payments.get(account);
//		Set<Integer> keys = payments.keySet();
//		String acc = Integer.toString(account);
//		//if(payments.containsKey(keys))
////		System.out.println("connected"+payments.containsKey(keys));
//		if(acc.equals(keys))
//			System.out.println("true");
//		else
//			System.out.println("false");
//		return pay;
//
//	}
	
	public Payment checkAccount(int k) {
		// TODO Auto-generated method stub
		Payment pay = payments.get(k);
		return pay;
	}

}
