package com.cg.bnk.bean;

/**
 * Hello world!
 *
 */
public class Payment 
{
	   private String name;
	   private int account;
	   private String ifsc;
	   private String mobile;
	   private String email;
	   private double bal;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAccount() {
		return account;
	}
	public void setAccount(int account) {
		this.account = account;
	}
	public String getIfsc() {
		return ifsc;
	}
	public void setIfsc(String ifsc) {
		this.ifsc = ifsc;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}

	
	public double getBal() {
		return bal;
	}
	public void setBal(double bal) {
		this.bal = bal;
	}

	
	@Override
	public String toString() {
		return "Payment [name=" + name + ", account=" + account + ", ifsc=" + ifsc + ", mobile=" + mobile + ", email="
				+ email + ", bal=" + bal + "]";
	}
	
	
	
	public Payment(String name, int account, String ifsc, String mobile, String email, double bal) {
		super();
		this.name = name;
		this.account = account;
		this.ifsc = ifsc;
		this.mobile = mobile;
		this.email = email;
		this.bal = bal;
	}
	public Payment() {
		
	}
}
