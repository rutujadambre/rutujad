package com.cg.bnk.service;

import java.util.ArrayList;

import com.cg.bnk.bean.Payment;
import com.cg.bnk.bean.PaymentPassword;
import com.cg.bnk.bean.Transaction;
import com.cg.bnk.dao.PaymentDAO;
import com.cg.bnk.dao.PaymentDAOImpl;
import com.cg.bnk.exception.BankException;

public class PaymentServiceImpl implements PaymentService{

	PaymentDAO dao;
	
	public PaymentServiceImpl()
	{
		dao = new PaymentDAOImpl();
	}


	public Payment getPayment(int account) throws BankException{
		// TODO Auto-generated method stub
		return dao.getPayment(account);
	}


	public Payment addAccount(Payment pay) throws BankException {
		// TODO Auto-generated method stub
		pay = dao.addAccount(pay);
		return pay;
	}


	@Override
	public Payment toAddMoney(double bal, int account) throws BankException {
		// TODO Auto-generated method stub
		return dao.toAddMoney(bal, account);
	}


	@Override
	public Payment toTransferFund(int acc1, int acc2, double bal) throws BankException {
		// TODO Auto-generated method stub
		return dao.toTransferFund(acc1, acc2, bal);
	}


	@Override
	public Payment checkAccount(int k) throws BankException {
		// TODO Auto-generated method stub
		return dao.checkAccount(k);
		
	}


	@Override
	public PaymentPassword addPasswordAccount(PaymentPassword pass) throws BankException {
		// TODO Auto-generated method stub
		pass = dao.addPasswordAccount(pass);
		return pass;
	}


	@Override
	public Transaction addDetail(Transaction trans) throws BankException {
		// TODO Auto-generated method stub
		trans = dao.addDetail(trans);
		return trans;
	}


	@Override
	public Transaction getDetail(int id) throws BankException {
		// TODO Auto-generated method stub
		return dao.getDetail(id);
	}


//	@Override
//	public Payment checkAccount() {
//		// TODO Auto-generated method stub
//		return dao.checkAccount();
//	}


//	@Override
//	public Payment checkAccount(int account) {
//		// TODO Auto-generated method stub
//		return dao.checkAccount(account);
//	}

}
