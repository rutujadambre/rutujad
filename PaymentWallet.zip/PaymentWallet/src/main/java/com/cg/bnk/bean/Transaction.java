package com.cg.bnk.bean;

import java.time.LocalDate;

public class Transaction {
	int transacId;
	int accountNo;
	int amount;
	LocalDate Date;
	LocalDate time;
//	public int getTransacId() {
//		return transacId;
//	}
	public void setTransacId(int transacId) {
		this.transacId = transacId;
	}
	public int getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	public LocalDate getDate() {
		return Date;
	}
	public void setDate(LocalDate date) {
		Date = date;
	}
	public LocalDate getTime() {
		return time;
	}
	public void setTime(LocalDate time) {
		this.time = time;
	}
	public int getTransacId() {
		// TODO Auto-generated method stub
		return transacId;
	}
	
	
}
