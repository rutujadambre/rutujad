package com.cg.bnk.ui;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Map;
import java.util.Random;
import java.util.Scanner;
import java.util.Set;

import com.cg.bnk.bean.Payment;
import com.cg.bnk.bean.PaymentPassword;
import com.cg.bnk.bean.Transaction;
import com.cg.bnk.dao.PaymentDAO;
import com.cg.bnk.dao.PaymentDAOImpl;
import com.cg.bnk.exception.BankException;
//import com.cg.bnk.exception.BankException;
import com.cg.bnk.service.PaymentService;
import com.cg.bnk.service.PaymentServiceImpl;
//import com.cg.bnk.service.Validator;
import com.cg.bnk.service.Validator;

public class Main {

	public static void main(String[] args)
	{
		Transaction transac = new Transaction();
		PaymentService service = new PaymentServiceImpl();
		Validator validator = new Validator();
		Payment pay = new Payment();
		PaymentPassword pass = new PaymentPassword();
		int n;
		do
		{	
			Scanner sc = new Scanner(System.in);
			//System.out.println("\n1.Registeration\n2.Add account\n3.To Add Money \n4.To transfer money\n5.Show details \n6.Show Balance \n7.Exit ");
			System.out.println("\n1.Registration \n2.Exit");
			System.out.println("Enter option : ");
			
			n = sc.nextInt();
			
			switch(n) {
			
			case 1:
			{
				System.out.println("Enter Email ID : ");
				String email1 = sc.next();
				System.out.println("Enter password : ");
				String password = sc.next();
				System.out.println("Enter confirm password: ");
				String password1 = sc.next();
				int n1;
				if(password.equals(password1))
				{
					try {
						pass = service.addPasswordAccount(pass);
					} catch (BankException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					do{System.out.println("\n1.Add account \n2.To Add Money \n3.To transfer money \n4.Show details \n5.Show Balance \n6.Show Transaction Detail");
					System.out.println("Enter : ");
					 n1 = sc.nextInt();
					 	switch(n1) {
					 	case 1:
					 	{
					 		try {
								System.out.println("Enter Name : ");
								String name = sc.next();
								
								System.out.println("Enter Mobile number : ");
								String mobile = sc.next();
								if(validator.validateMobile(mobile)==false)
									throw new BankException("Enter ten digit number");
								
								System.out.println("Enter Email ID : ");
								String email = sc.next();
								
								
								System.out.println("Enter IFSC code : ");
								String ifsc = sc.next();
								
								System.out.println("Enter Account number : ");
								int account = sc.nextInt();
								if(validator.validateAccount(Integer.toString(account))==false)
									throw new BankException("Invalid Account number");
//								String ac = Integer.toString(account);
								
								
								
								//pay = service.checkAccount(account);
							
								
//								Random ran = new Random();
//								int a = ran.nextInt(90000);
								//System.out.println("Balance"+a);
								
								pay.setName(name);
								pay.setMobile(mobile);
								pay.setEmail(email);
								pay.setAccount(account);
								pay.setIfsc(ifsc);
								//pay.setBal(a);
								//String acc = Integer.toString(account);
								//pay = service.addAccount(pay);
								//int ss = service.checkAccount(0);
								if(service.checkAccount(account)==null)
								{
									System.out.println("This Account does not Exist");
								}
								else
								{
									System.out.println("Successfully Linked");
								}
								}
								catch(BankException e)
								{
									System.out.println(e.getMessage());
								}
								break;
					 	}
								
					 	case 2:
					 		{
					 			try
								{
					 			System.out.println("Enter your account number to add money : ");
								int accoun = sc.nextInt();
								System.out.println("Enter the amount to add money : ");
								double bal = sc.nextDouble();
								
									pay = service.toAddMoney(bal, accoun);
									
									int sum = 0;
									bal = bal + sum;
									Random ran = new Random();
									int a = ran.nextInt(90000);
									transac.setAccountNo(accoun);
									transac.setTransacId(a);
									transac.setAmount((int) bal);
									transac.setDate(LocalDate.now());
									
									transac = service.addDetail(transac);
									System.out.println("Your wallet has "+bal+" money");
									System.out.println("Your Transaction ID is : "+a);
								}catch(Exception e)
								{
									System.out.println("account ");
								}
								break;
					 		}
					 		
						case 3:
							{
								try {
								System.out.println("Enter your account number : ");
								int a1 = sc.nextInt();
								System.out.println("Enter sender account number : ");
								int a2 = sc.nextInt();
								System.out.println("Balance : ");
								double b = sc.nextDouble();
								pay = service.toTransferFund(a1, a2, b);
								
								Random ran = new Random();
								int a = ran.nextInt(900000)+100000;
								transac.setAccountNo(a1);
								transac.setTransacId(a);
								transac.setAmount((int) b);
								transac.setDate(LocalDate.now());
								
								transac = service.addDetail(transac);
								System.out.println("Your Transaction ID is : "+a);
								} catch (BankException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}
								break;
							}
						case 4:
							{
								try {
								System.out.println("Enter account number : ");
								int accoun = sc.nextInt();
								if(validator.validateAccount(Integer.toString(accoun))==false)
									throw new BankException("Invalid account number");
								else 
								{	
									pay = service.getPayment(accoun);
								
								System.out.println("Account : "+pay.getAccount());
								System.out.println("Name : "+pay.getName());
								System.out.println("IFSC number : "+pay.getIfsc());
								System.out.println("Mobile number : "+pay.getMobile());
								System.out.println("Email : "+pay.getEmail());
								System.out.println("Balance : "+pay.getBal());
								}
								}catch(BankException e)
								{
									System.out.println(e.getMessage());
								}
								break;
							}
						case 5:
							{
								try
								{
								System.out.println("Enter account number : ");
								int accoun = sc.nextInt();
								if(validator.validateAccount(Integer.toString(accoun))==false)
									throw new BankException("Invalid account number");
								else 
								{	
									pay = service.getPayment(accoun);
									System.out.println("Balance : "+pay.getBal());
								}
								}catch(BankException e)
								{
									System.out.println(e.getMessage());
								}
								break;
								
							}
						case 6:
						{
							System.out.println("Enter Transaction ID : ");
							int transactionId = sc.nextInt();
							
							try {
								transac = service.getDetail(transactionId);
								System.out.println("Account No: "+transac.getAccountNo());
								System.out.println("Amount: "+transac.getAmount());
								System.out.println("Date: "+transac.getDate());
							} catch (BankException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
							
						}
					 	}
					}while(n1!=6);
			
				}
				else
				{
					System.out.println("Please enter same passwords ");
				}
				break;
			}
//			case 2:
//			{
//				try {
//				System.out.println("Enter Name : ");
//				String name = sc.next();
//				
//				System.out.println("Enter Mobile number : ");
//				String mobile = sc.next();
//				if(validator.validateMobile(mobile)==false)
//					throw new BankException("Enter ten digit number");
//				
//				System.out.println("Enter Email ID : ");
//				String email = sc.next();
//				
//				
//				System.out.println("Enter IFSC code : ");
//				String ifsc = sc.next();
//				
//				System.out.println("Enter Account number : ");
//				int account = sc.nextInt();
//				if(validator.validateAccount(Integer.toString(account))==false)
//					throw new BankException("Invalid Account number");
////				String ac = Integer.toString(account);
//				
//				
//				
//				//pay = service.checkAccount(account);
//			
//				
////				Random ran = new Random();
////				int a = ran.nextInt(90000);
//				//System.out.println("Balance"+a);
//				
//				pay.setName(name);
//				pay.setMobile(mobile);
//				pay.setEmail(email);
//				pay.setAccount(account);
//				pay.setIfsc(ifsc);
//				//pay.setBal(a);
//				//String acc = Integer.toString(account);
//				//pay = service.addAccount(pay);
//				//int ss = service.checkAccount(0);
//				if(service.checkAccount(account)==null)
//				{
//					System.out.println("This Account does not Exist");
//				}
//				else
//				{
//					System.out.println("Successfully Linked");
//				}
//				}
//				catch(BankException e)
//				{
//					System.out.println(e.getMessage());
//				}
//				
//				
//				break;
//			}
//			case 3:
//			{
//				System.out.println("Enter your account number to add money : ");
//				int accoun = sc.nextInt();
//				System.out.println("Enter the amount to add money : ");
//				double bal = sc.nextDouble();
//				try
//				{
//					pay = service.toAddMoney(bal, accoun);
//				}catch(Exception e)
//				{
//					System.out.println("account ");
//				}
//				break;
//			}
//			case 4:
//			{
//				System.out.println("Enter your account number : ");
//				int a1 = sc.nextInt();
//				System.out.println("Enter sender account number : ");
//				int a2 = sc.nextInt();
//				System.out.println("Balance : ");
//				double b = sc.nextDouble();
//				pay = service.toTransferFund(a1, a2, b);
//				break;
//			}
//			case 5:
//			{
//				try {
//				System.out.println("Enter account number : ");
//				int accoun = sc.nextInt();
//				if(validator.validateAccount(Integer.toString(accoun))==false)
//					throw new BankException("Invalid account number");
//				else 
//				{	
//					pay = service.getPayment(accoun);
//				
//				System.out.println("Account : "+pay.getAccount());
//				System.out.println("Name : "+pay.getName());
//				System.out.println("IFSC number : "+pay.getIfsc());
//				System.out.println("Mobile number : "+pay.getMobile());
//				System.out.println("Email : "+pay.getEmail());
//				System.out.println("Balance : "+pay.getBal());
//				}
//				}catch(BankException e)
//				{
//					System.out.println(e.getMessage());
//				}
//				break;
//			}
//			case 6:
//			{
//				try
//				{
//				System.out.println("Enter account number : ");
//				int accoun = sc.nextInt();
//				if(validator.validateAccount(Integer.toString(accoun))==false)
//					throw new BankException("Invalid account number");
//				else 
//				{	
//					pay = service.getPayment(accoun);
//					System.out.println("Balance : "+pay.getBal());
//				}
//				}catch(BankException e)
//				{
//					System.out.println(e.getMessage());
//				}
//				break;
//				
//			}
			case 2: 
			{
				System.exit(0);
				
			}
			
				
			}
		}while(n!=2);
		
		
	}
}
