package com.cg.bnk.bean;

import java.sql.Date;


public class Transaction {
	int transactionId;
	int accountNo;
	int amount;
	Date transactionDate;
	//LocalDate time;
//	public int getTransacId() {
//		return transacId;
//	}
	public void setTransactionId(int transacId) {
		this.transactionId = transacId;
	}
	public int getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}

	public int getTransactionId() {
		// TODO Auto-generated method stub
		return transactionId;
	}
	public Date getTransactionDate() {
		return transactionDate;
	}
	public void setTransactionDate(Date transactionDate) {
		this.transactionDate = transactionDate;
	}
	@Override
	public String toString() {
		return "Transaction [transactionId=" + transactionId + ", accountNo=" + accountNo + ", amount=" + amount
				+ ", transactionDate=" + transactionDate + "]";
	}
	
	
}
