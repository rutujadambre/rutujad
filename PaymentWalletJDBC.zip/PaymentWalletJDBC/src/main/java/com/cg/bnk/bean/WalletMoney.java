package com.cg.bnk.bean;

public class WalletMoney {
	
	private int account;
	
	private int balance;

	public int getAccount() {
		return account;
	}

	public void setAccount(int account) {
		this.account = account;
	}

	public int getBalance() {
		return balance;
	}

	public void setBalance(int balance) {
		this.balance = balance;
	}

	@Override
	public String toString() {
		return "WalletMoney \nbalance=" + balance ;
	}

	public WalletMoney(int account, int balance) {
		super();
		this.account = account;
		this.balance = balance;
	}

	public WalletMoney() {
		super();
		// TODO Auto-generated constructor stub
	}

	
}
