package com.cg.bnk.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.cg.bnk.bean.Payment;
import com.cg.bnk.bean.PaymentPassword;
import com.cg.bnk.bean.Transaction;
import com.cg.bnk.bean.WalletMoney;
import com.cg.bnk.exception.BankException;



public class PaymentDAOImpl implements PaymentDAO{
	

	Connection con;
	public PaymentDAOImpl() {
		// TODO Auto-generated constructor stub
	con=DatabaseConnection.getConnection();
	}
	Payment pay = new Payment();
	
	PaymentPassword pass = new PaymentPassword();
	
	Transaction trans = new Transaction();
	
	WalletMoney money = new WalletMoney();
	
	public Payment getPayment(int account) {
		// TODO Auto-generated method stub
		String sql = "select name,account,ifsc,mobile,email,bal from bank where account = ?";
		
		PreparedStatement ps;
		try {
			ps = con.prepareStatement(sql,ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_UPDATABLE);
			ps.setInt(1, account);
			ResultSet rs= ps.executeQuery();
			
			
			while(rs.next())
			{
				String name = rs.getString(1);
				int acc = rs.getInt(2);
				String ifsc = rs.getString(3);
				String mob = rs.getString(4);
				String email = rs.getString(5);
				int bal = rs.getInt(6);
				
				pay.setName(name);
				pay.setAccount(acc);
				pay.setIfsc(ifsc);
				pay.setMobile(mob);
				pay.setEmail(email);
				pay.setBal(bal);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return pay ;
	
	}
	public Payment addAccount(Payment pay){
	return pay;
	}
	
	public Payment toAddMoney(int bal, int account) {

		String sql = "update bank set bal = ? where account = ?";
		
		PreparedStatement ps;
		try {
			ps = con.prepareStatement(sql,ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_UPDATABLE);
			ps.setDouble(1, bal);
			ps.setInt(2, account);
			
			int rowsUpdated = ps.executeUpdate();
			if(rowsUpdated > 0) {
				System.out.println("updated");
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return pay;
	}
	
//	public Payment toTransferFund(int acc1, int acc2, double bal) {
//
//		return pay;
//
//	}

	public Payment toTransferMoney(int bal, int account) throws BankException {
		// TODO Auto-generated method stub
		String sql = "update bank set bal = ? where account = ?";
		
		PreparedStatement ps;
		try {
			ps = con.prepareStatement(sql,ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_UPDATABLE);
			ps.setDouble(1, bal);
			ps.setInt(2, account);
			
			int rowsUpdated = ps.executeUpdate();
			if(rowsUpdated > 0) {
				System.out.println("updated");
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return pay;
	}
	
	public Payment checkAccount(int acco,String ifsc,String name,String email) {
		// TODO Auto-generated method stub
//		Payment pay = payments.get(k);
		String sql = "select name,account,ifsc,mobile,email,bal from bank where account = ? and name=? and ifsc = ? and email = ?";
		//Connection con= DatabaseConnection.getConnection();
		
		PreparedStatement ps;
		try {
			ps = con.prepareStatement(sql,ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_UPDATABLE);
			ps.setInt(1, acco);
			ps.setString(2, name);
			ps.setString(3, ifsc);
			ps.setString(4, email);
			ResultSet rs= ps.executeQuery();
			
			
			if(rs.next())
			{

				
				System.out.println("linked");
			}
			else
			{
				System.out.println("somthing is wrong");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return pay ;
	}
	
	public PaymentPassword addPasswordAccount(PaymentPassword pass) {
		// TODO Auto-generated method stub

		String sql = "insert into user_password values(?,?)";
		PreparedStatement ps;
		try {
			int count = 0;
			ps = con.prepareStatement(sql);
			ps.setString(1, pass.getEmail());
			ps.setString(2, pass.getPassword());
			
			count = ps.executeUpdate();
			System.out.println("You are successfully registered");
		}catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return pass;
//		payments.put(pay.getAccount(), pay);
//		return pay;
	}
	
	public PaymentPassword getPasswordEmail(String password)
	{
		String sql = "Select email,password from  user_password where email = ? ";
		PreparedStatement ps;
		try {
			ps = con.prepareStatement(sql,ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_UPDATABLE);
			ps.setString(1, password);
	
			ResultSet rs= ps.executeQuery();
			
			
			while(rs.next())
			{
				String email1 = rs.getString(1);
				String password1 = rs.getString(2);
				
				pass.setEmail(email1);
				pass.setPassword(password1);
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return pass ;
		
	}
	
	
	public Transaction addDetail(Transaction trans) throws BankException {
		String sql = "Insert into transaction values(?,?,?,?)";
		PreparedStatement ps;
		try {
			ps = con.prepareStatement(sql);
			ps.setInt(1, trans.getTransactionId());
			ps.setInt(2, trans.getAccountNo());
			ps.setInt(3, trans.getAmount());
			ps.setDate(4, trans.getTransactionDate());
	
			 ps.executeQuery();
			
			System.out.println("date inserted");
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return trans;
	}
	
	public Transaction transactionHistory(int accountNo) throws BankException {
		String sql = "select t1.transactionid,t1.accountno,t1.amount,t1.transactiondate from transaction t1 join bank t2 on t1.accountno=t2.account where t1.accountno = ?";
		int count = 0;
		PreparedStatement ps;
		try {
			ps = con.prepareStatement(sql,ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_UPDATABLE);
			ps.setInt(1, accountNo);
			
			ResultSet rs= ps.executeQuery();
			
			while(rs.next())
			{
				int transacId = rs.getInt(1);
				int accno = rs.getInt(2);
				int amount1 = rs.getInt(3);
				Date date1 = rs.getDate(4);
				
				trans.setTransactionId(transacId);
				trans.setAccountNo(accno);
				trans.setAmount(amount1);
				trans.setTransactionDate(date1);
				
				count++;
				
				System.out.println(count+". "+trans);
				
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		return trans;
	}
	@Override
	public WalletMoney addWalletBalance(WalletMoney money) throws BankException {
		// TODO Auto-generated method stub
		String sql = "Insert into wallet values(?,?)";
		PreparedStatement ps;
		try {
			ps = con.prepareStatement(sql);
			ps.setInt(1, money.getAccount());
			ps.setInt(2, money.getBalance());
			
	
			 ps.executeQuery();
			
			System.out.println("date inserted");
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return money;
	}
	@Override
	public WalletMoney getWalletinfo(int account) throws BankException {
		// TODO Auto-generated method stub
		String sql = " select sum(balance) from wallet where account=?";
		
		PreparedStatement ps;
		try {
			ps = con.prepareStatement(sql,ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_UPDATABLE);
			ps.setInt(1, account);
			
			ResultSet rs= ps.executeQuery();
			
			while(rs.next())
			{
				int bal = rs.getInt(1);
				
				
				money.setBalance(bal);
				
				System.out.println(money);
				
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		return money;
	}
}
