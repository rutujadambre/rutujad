/*
 * package com.cg.psa.bean;
 * 
 * import java.sql.Date;
 * 
 * import javax.persistence.Column; import javax.persistence.Entity; import
 * javax.persistence.Id; import javax.persistence.Table;
 * 
 * import com.poiji.annotation.ExcelCellName;
 * 
 * @Entity
 * 
 * @Table(name="employeesource") public class EmployeeSource2 {
 * 
 * 
 * @ExcelCellName("Check Status")
 * 
 * @Column(name="status") private boolean empStatus;
 * 
 * @ExcelCellName("Emp Id")
 * 
 * @Id
 * 
 * @Column(name="Id") private boolean empId;
 * 
 * @ExcelCellName("Emp Name")
 * 
 * @Column(name="empName") private String empName;
 * 
 * @ExcelCellName("E-mail Id")
 * 
 * @Column(name="email") private String empEmail;
 * 
 * @ExcelCellName("Gender")
 * 
 * @Column(name="gender") private String empGender;
 * 
 * @ExcelCellName("Designation")
 * 
 * @Column(name="designation") private String empDesignation;
 * 
 * @ExcelCellName("BU")
 * 
 * @Column(name="BU") private String empBU;
 * 
 * @ExcelCellName("SBU / Service Line")
 * 
 * @Column(name="SBU") private String empSBU;
 * 
 * @ExcelCellName("Account")
 * 
 * @Column(name="empAccount") private String empAccount;
 * 
 * @ExcelCellName("N+1 Name")
 * 
 * @Column(name="empManagerName") private String empManagerName;
 * 
 * 
 * @ExcelCellName("N+1 Email")
 * 
 * @Column(name="empManagerEmail") private String empManagerEmail;
 * 
 * 
 * @ExcelCellName("Project Country")
 * 
 * @Column(name="empProjectCountry") private String empProjectCountry;
 * 
 * 
 * 
 * 
 * @ExcelCellName("Engagement Manager")
 * 
 * @Column(name="empEngagementManager") private String empEngagementManager;
 * 
 * 
 * 
 * }
 */