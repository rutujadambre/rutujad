package com.cg.psa.bean;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name="employeeinsights")
public class EmpTesting {
	
	
	
	@Column(name="sbu")
	private String sbuName;
	
	@Column(name="bu")
	private String buName;
	
	@Column(name="account")
	private String accountName;
	
	@Column(name="proj_country")
	private String projectLocation;
	
	
	@Id
	@Column(name="empid")
	 private int empId;
	
	@Column(name="gender")
	 private String gender;
	
	@Column(name="desig")
	 private String designation;
	
	@Column(name="name")
	 private String name;
	
	@Column(name="mgr_name")
	 private String managerName;
	
	@Column(name="pri_skils")
	 private String skills;
	
	@Column(name="email")
	private String email;
	
	@Column(name="domain")
	private String domain;
	
	
	
	
	
	public String getSkills() {
		return skills;
	}
	public void setSkills(String skills) {
		this.skills = skills;
	}
	@Override
	public String toString() {
		return "EmpTesting [sbuName=" + sbuName + ", buName=" + buName + ", accountName=" + accountName
				+ ", projectLocation=" + projectLocation + ", empId=" + empId + ", gender=" + gender + ", designation="
				+ designation + ", name=" + name + ", managerName=" + managerName + ", skills=" + skills + "]";
	}
	public String getSbuName() {
		return sbuName;
	}
	public void setSbuName(String sbuName) {
		this.sbuName = sbuName;
	}
	public String getBuName() {
		return buName;
	}
	public void setBuName(String buName) {
		this.buName = buName;
	}
	public String getAccountName() {
		return accountName;
	}
	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}
	public String getProjectLocation() {
		return projectLocation;
	}
	public void setProjectLocation(String projectLocation) {
		this.projectLocation = projectLocation;
	}
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getManagerName() {
		return managerName;
	}
	public void setManagerName(String managerName) {
		this.managerName = managerName;
	}
	public EmpTesting() {
		super();
		// TODO Auto-generated constructor stub
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getDomain() {
		return domain;
	}
	public void setDomain(String domain) {
		this.domain = domain;
	}
	 
	 
}
