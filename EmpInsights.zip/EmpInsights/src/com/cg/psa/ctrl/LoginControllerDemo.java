package com.cg.psa.ctrl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.cg.psa.bean.EmpTesting;
import com.cg.psa.bean.Login;
import com.cg.psa.service.IEmpInsightsService;
import com.cg.psa.validator.UserValidator;




@Controller
public class LoginControllerDemo {
	//EmpFileJoiner empFileJoiner=new EmpFileJoiner();
	int empid;
	@Autowired
	IEmpInsightsService service = null;
	UserValidator userValidator=new UserValidator();
	public IEmpInsightsService getService() {
		return service;
	}

	public void setService(IEmpInsightsService service) {
		this.service = service;
	}



	@RequestMapping(value="/HomePage")
	public String displayLoginPage(Model model) {
		Login log = new Login();
		EmpTesting et=new EmpTesting();
		model.addAttribute("login", log);
		return"LoginPage";
	}

	@RequestMapping(value="/ValidateUser")
	public String validateUser(@ModelAttribute("login")Login login,Model model)
	{
		Login log = new Login();
		EmpTesting et = new EmpTesting();
		System.out.println(login.getEmpId());
		if (userValidator.validId(login.getEmpId())==false) {

			model.addAttribute("errorMsg", "Enter Correct Employee Id");
			return "LoginPage";
		} 
		else {
			log = service.getLoginDetails(login.getEmpId());
			et = service.getEmployeeDetailsbyId(login.getEmpId());
			if (log == null) {

				model.addAttribute("errorMsg", "User Doesn't Exist");
				return "LoginPage";
			} else if (log.getPassword().equals(login.getPassword())) {

				if (et.getDesignation().equalsIgnoreCase("Manager")) {
					return "redirect:/bu.obj";
				} else if (et.getDesignation().equalsIgnoreCase("BUHead")) {
					return "redirect:/sbu.obj";
				} else {
					model.addAttribute("errorMsg", "User Access Prohibited");
					return "LoginPage";
				}
			} else if(log.getPassword().equals(login.getPassword())==false)
				model.addAttribute("psdErrorMsg", "Password is wrong");
			return "LoginPage";
		}
	}


	@RequestMapping(value="/sbu")
	public String EmpInfoBySBU(Model model) {

		Login log = new Login();
		EmpTesting empTest= new EmpTesting();
		model.addAttribute("et1",empTest);

		ArrayList<String> sbuList=  service.getAllSBU();

		model.addAttribute("sbulist", sbuList);
		//add bu
		ArrayList<String> buList= service.getAllBU();

		model.addAttribute("bulist", buList);   

		ArrayList<String> account = service.getAllAccount();

		model.addAttribute("account", account);
		
		ArrayList<String> location = service.getAllLocation();

		model.addAttribute("location", location);
		
		ArrayList<String> skills = service.getAllSkills();
		

		model.addAttribute("skill", skills);
		
		
		return "BUHome";	
	}
	

	@RequestMapping(value="/bu")
	public String MgrInfoBySBU(Model model) {

		Login log = new Login();
		EmpTesting empTest= new EmpTesting();
		model.addAttribute("et1",empTest);
		
		ArrayList<String> location = service.getAllLocation();

		model.addAttribute("location", location);
		
		ArrayList<String> skills = service.getAllSkills();
		

		model.addAttribute("skill", skills);
		
		
		return "ManagerHome";	
	}
	
	@RequestMapping(value="/sbuListFinal")
	public String EmpInfoBySBUFinal(@ModelAttribute("et1")EmpTesting empTest,Model model) {
		ArrayList<EmpTesting> List=service.fetchAllUsers(empTest.getSbuName(),empTest.getBuName(),empTest.getAccountName(),empTest.getProjectLocation(),empTest.getSkills(),0,2);
		
		model.addAttribute("List", List);
		return "SBUResult";	
	}

	@RequestMapping(value="/buListFinal")
	public String EmpInfoByBU(@ModelAttribute("et1")EmpTesting empTest,Model model) {
		ArrayList<EmpTesting> List=service.fetchUsersMgr(empTest.getProjectLocation(), empTest.getSkills());
		model.addAttribute("List", List);
		return "SBUResult";	
	}


	/*
	 * @RequestMapping(value="/buListFinal") public String
	 * EmpInfoByBUFinal(@ModelAttribute("et1")EmpTesting empTest,Model model) {
	 * ArrayList<EmpTesting> List=service.fetchAllUsersBU(empTest.getBuName());
	 * model.addAttribute("List",List); return "SBUResult"; }
	 */

	@RequestMapping(value = "/loadSbu", headers = "Accept=*/*", method = RequestMethod.GET)
	public @ResponseBody
	ArrayList<String> loadStates(@RequestParam(value = "sbuNameOption", required = true) Integer sbuNameOption) throws IllegalStateException {

		//Specify the returning object you want here
		return null;
	}

	@RequestMapping(value="/forgotpassword")
	public String forgotPassword(Model model) {
		EmpTesting et=new EmpTesting();
		model.addAttribute("otp", et);
		return "ForgotPassword";	
	}


	@RequestMapping(value="/otpVerification")
	public String otpGenergate(@ModelAttribute("otp")EmpTesting empTest,Model model) {
		Login log = new Login();
		EmpTesting et=service.getEmployeeDetailsbyemial(empTest.getEmpId());

		if(et==null) {
			model.addAttribute("error", "Account id does not exist");
			return "ForgotPassword";
		}
		else if(et.getEmail().equals(empTest.getEmail())==false) {
			model.addAttribute("error1", "Email does not match");
			return "ForgotPassword";
		}
		else
			model.addAttribute("password", log);
		empid=empTest.getEmpId();
		return "OtpVerification";	

	}

	@RequestMapping(value="/pwdReset")
	public String passwordReset(@ModelAttribute("password")Login log,Model model) {
		if(log.getEmpId()==1111) {

			Login login =service.setPasswordDetails(log.getPassword(), empid);
			return "confirmChangePassword";	
		}else
			model.addAttribute("msg", "Otp not correct");
		return "OtpVerification";

	}

	
	//Code for Dynamic dropdown
	/*	@RequestMapping(value = "/sbu/{buName}", method = RequestMethod.GET)
		public @ResponseBody  ArrayList<String> getAllSubcategories(@PathVariable("buName") String sbu) {
		    return service.getAllBU();
		}*/
	
	//Code for Pagination
	  @RequestMapping(value="/viewemp/{pageid}")    
	    public String edit(@PathVariable int pageid,Model m){    
	        int total=5;    
	        if(pageid==1){}    
	        else{    
	            pageid=(pageid-1)*total+1;    
	        }    
	        System.out.println(pageid);  
	        List<EmpTesting> list=service.getEmployeesByPage(pageid,total);    
	          m.addAttribute("msg", list);  
	        return "viewemp";    
	    }    



}
