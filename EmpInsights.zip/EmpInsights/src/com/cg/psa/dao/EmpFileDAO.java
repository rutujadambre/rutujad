package com.cg.psa.dao;

import java.io.File;
import java.sql.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

import com.cg.psa.exception.UserException;
import com.cg.psa.util.FileUtil;

public class EmpFileDAO {
	
	FileUtil util=new FileUtil();
	private String url;
	File[] getFiles() throws UserException
	{
		url=FileUtil.fileUrl();	
		
		File folder = new File(url);
		File[] listOfFiles = folder.listFiles();

		for (int i = 0; i < listOfFiles.length; i++) {
		  if (listOfFiles[i].isFile()) {
		    System.out.println(listOfFiles[i].getName());
		  } else if (listOfFiles[i].isDirectory()) {
		    System.out.println("Directory " + listOfFiles[i].getName());
		  }
		}
		return listOfFiles;
	    
	    
	    
	    
	}
	
	boolean checkFileModification(Date date)
	{
		
		DateFormat df = new SimpleDateFormat("dd:MM:yy:HH:mm:ss");
		String dateString=df.format(date);
		return false;
		//fetch database and check currentDate and if mismatches return true
		
	}



}
