package com.cg.psa.service;

import java.io.File;
import java.io.FileInputStream;


import com.cg.psa.exception.UserException;
import com.cg.psa.util.FileUtil;

public class EmpFileJoiner {
	
	FileUtil util=new FileUtil();
	private String url;
	
	@SuppressWarnings("deprecation")
	public void fileJoiner() throws UserException
	{
		
		//check number of file and fetch their file name and store it into database
		//get the file from cronJobFileDao
		//call EmployeeJDBCDAO.storeExcelData()
	}
	
	
	

}
