var SBUArra = new Array("APPS2EUROPE", "APPS2NORTHAMERICA", "APPS2INDIA");
function SBU() {
	var SBUObj = window.document.formRegister.txtsbu;
	for (var i = 0; i < SBUArra.length; i++) {
		SBUObj.options[i] = new Option(SBUArra[i], SBUArra[i]);
	}
}
// ****************************************
var BUArra = new Array();
BUArra[0] = new Array("BU1", "BU2", "BU3");
BUArra[1] = new Array("BU4", "BU5", "BU6");
BUArra[2] = new Array("BU7", "BU8", "BU9");
function BU() {
	var SBUDataObj = window.document.formRegister.txtsbu;
	var BUDataObj = window.document.formRegister.txtbu;
	var indexOfSBUSelected = SBUDataObj.selectedIndex;
	for (var j = 0; j < BUArra.length; j++) {
		BUDataObj.options[j] = new Option(BUArra[indexOfSBUSelected][j],
				BUArra[indexOfSBUSelected][j]);

	}
}
// ********************************
var AccArra = new Array();
// AccArra[0] = new Array("BU11", "BU12", "BU13");
// AccArra[1] = new Array("BU14", "BU15", "BU16");
// AccArra[2] = new Array("BU17", "BU18", "BU19");
// AccArra[3] = new Array("BU21", "BU22", "BU23");
// AccArra[4] = new Array("BU24", "BU25", "BU26");
// AccArra[5] = new Array("BU27", "BU28", "BU29");
// AccArra[6] = new Array("BU31", "BU32", "BU33");
// AccArra[7] = new Array("BU34", "BU35", "BU36");
// AccArra[8] = new Array("BU37", "BU38", "BU39");
function Account() {
	var SBUDataObj1 = window.document.formRegister.txtbu;
	var BUDataObj1 = window.document.formRegister.txtbu1;
	var indexOfSBUSelected1 = SBUDataObj1.selectedIndex;
	if (indexOfSBUSelected1 == 0) {
		AccArra[0] = new Array("BU11", "BU12", "BU13");
		AccArra[1] = new Array("BU14", "BU15", "BU16");
		AccArra[2] = new Array("BU17", "BU18", "BU19");
	}
	if (indexOfSBUSelected1 == 1) {
		AccArra[0] = new Array("BU21", "BU22", "BU23");
		AccArra[1] = new Array("BU24", "BU25", "BU26");
		AccArra[2] = new Array("BU27", "BU28", "BU29");
	}
	if (indexOfSBUSelected1 == 2) {
		AccArra[0] = new Array("BU31", "BU32", "BU33");
		AccArra[1] = new Array("BU34", "BU35", "BU36");
		AccArra[2] = new Array("BU37", "BU38", "BU39");
	}
	for (var j = 0; j < AccArra.length; j++) {
		BUDataObj1.options[j] = new Option(AccArra[indexOfSBUSelected1][j],
				AccArra[indexOfSBUSelected1][j]);

	}
}

// *************************************

