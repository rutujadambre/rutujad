package com.cg.bnk.controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.bnk.bean.Payment;
import com.cg.bnk.bean.PaymentPassword;
import com.cg.bnk.bean.Transaction;
import com.cg.bnk.bean.WalletMoney;
import com.cg.bnk.exception.BankException;
import com.cg.bnk.service.PaymentService;

@Controller
public class WalletController {

	@Autowired
	PaymentService service = null;

	public PaymentService getService() {
		return service;
	}

	public void setService(PaymentService service) {
		this.service = service;
	}

	@RequestMapping(value = "/ShowLoginPage")
	public String displayLoginPage(Model model) {
		PaymentPassword login = new PaymentPassword();
		model.addAttribute("wallet", login);
		return "Login";
	}

	@RequestMapping(value = "/LoginValidate")
	public String validateUser(@ModelAttribute("wallet") PaymentPassword login, Model model) throws BankException {
		PaymentPassword user = service.getPasswordEmail(login.getEmail());
		if (user != null) {
			if (user.getPassword().equals(login.getPassword()) && user.getEmail().equals(login.getEmail())) {
				return "Success";
			} else if (user.getEmail().equals(login.getEmail())) {
				String msg = "Sorry Your Password is Wrong";
				model.addAttribute("SignUpMsg", msg);
				return "Login";
			} else {
				String msg1 = "Sorry Your account is Wrong";
				model.addAttribute("SignUpMsg1", msg1);
				return "Login";
			}
		} else {
			String msg2 = "Your account does not exist Please SignUp";
			model.addAttribute("ErrorMsg", msg2);
			return "Login";
		}
	}

	/******************************************/
	@RequestMapping(value = "/SignUp")
	public String signUpUser(Model model) {
		PaymentPassword login = new PaymentPassword();
		model.addAttribute("wallet", login);
		return "SignUpPage";
	}

	@RequestMapping(value = "/Registration")
	public String registerUser(@ModelAttribute("wallet") PaymentPassword login, Model model) throws BankException {
		PaymentPassword user = service.addPasswordAccount(login);
		return "Login";
	}

	/**************************************/

	@RequestMapping(value = "/LinkAccount")
	public String linkAccount(Model model) {
		Payment link = new Payment();
		model.addAttribute("wallet", link);
		return "LinkAccountPage";
	}

	@RequestMapping(value = "/AccountLinked")
	public String linkedAccount(@ModelAttribute("wallet") Payment link, Model model) throws BankException {
		// Payment linked = service.checkAccount(link.getAccount(), link.getIfsc(),
		// link.getName(), link.getEmail());
		Payment linked = service.getPayment(link.getAccount());
		if (linked != null) {
			if (linked.getIfsc().equals(link.getIfsc()) && linked.getAccount() == link.getAccount()
					&& linked.getEmail().equals(link.getEmail()) && linked.getName().equals(link.getName())
					&& linked.getMobile().equals(link.getMobile())) {
				model.addAttribute("acc",link.getAccount());
				model.addAttribute("name", link.getName());
				return "ListOfOperation";
			} else if (linked.getIfsc().equals(link.getIfsc()) && linked.getAccount() == link.getAccount()
					&& linked.getEmail().equals(link.getEmail()) && linked.getName().equals(link.getName())) {
				String msg = "Sorry Your Mobile No. is Wrong";
				model.addAttribute("ErrorUpMsg", msg);
				return "LinkAccountPage";
			} else if (linked.getIfsc().equals(link.getIfsc()) && linked.getAccount() == link.getAccount()
					&& linked.getName().equals(link.getName()) && linked.getMobile().equals(link.getMobile())) {
				String msg1 = "Sorry Your Email ID is Wrong";
				model.addAttribute("ErrorUpMsg1", msg1);
				return "LinkAccountPage";
			} else if (linked.getAccount() == link.getAccount() && linked.getEmail().equals(link.getEmail())
					&& linked.getName().equals(link.getName()) && linked.getMobile().equals(link.getMobile())) {
				String msg2 = "Sorry Your IFSC Code is Wrong";
				model.addAttribute("ErrorUpMsg2", msg2);
				return "LinkAccountPage";
			} else if (linked.getIfsc().equals(link.getIfsc()) && linked.getAccount() == link.getAccount()
					&& linked.getEmail().equals(link.getEmail()) && linked.getMobile().equals(link.getMobile())) {
				String msg3 = "Sorry Your Name is Wrong";
				model.addAttribute("ErrorUpMsg3", msg3);
				return "LinkAccountPage";
			}
	
			else {
				String msg4 = "Sorry Your Account No. is Wrong";
				model.addAttribute("ErrorUpMsg4", msg4);
				return "LinkAccountPage";
			}
		} else {
			String msg5 = "Something went Wrong Please Fill up detail again";
			model.addAttribute("ErrorUpMsg5", msg5);
			return "LinkAccountPage";
		}
	}

	/*************************************************/

	@RequestMapping(value = "/WalletMoney")
	public String walletMoney(Model model) {
		Payment bank = new Payment();
		model.addAttribute("wallet", bank);
		return "WalletMoney";
	}

	@RequestMapping(value = "/AddWalletMoney")
	public String addMoneyToWallet(@ModelAttribute("wallet") Payment bank, Model model) throws BankException {
		Payment pay1 = new Payment();
//		System.out.println(pay1.getBal());
//		System.out.println(bank.getBal());
//		if(pay1.getBal()<bank.getBal())
//		{
//			model.addAttribute("bal","Balance is above limit");
//			return "WalletMoney";
//		}
//		else
//		{
		//model.addAttribute("balance", bank.getBal());
		service.toAddMoney(bank.getBal(), bank.getAccount());
		WalletMoney money = new WalletMoney();
		money.setAccount(bank.getAccount());
		money.setBalance(bank.getBal());
		service.addWalletBalance(money);
		return "S";
	//	}

	}
	@RequestMapping(value="/ListOfOperation1")
	public String goHomePage1()
	{
		return "ListOfOperation";
	}
/****************************************/	

	@RequestMapping(value = "/Show")
	public String showDetail1(@RequestParam("account")int account,Model model) throws BankException {
		Payment pay=service.getPayment(account);
		ArrayList<Integer> m = service.getWalletinfo(account);
		//WalletMoney money = service.getWalletinfo(bank.getAccount());
		model.addAttribute("account", pay.getAccount());
		model.addAttribute("ifsc", pay.getIfsc());
		model.addAttribute("name", pay.getName());
		model.addAttribute("mobile", pay.getMobile());
		model.addAttribute("email", pay.getEmail());
		model.addAttribute("balList", m);
		model.addAttribute("accountBalance", pay.getBal());
		return "ShowDetail1";
	}
	@RequestMapping(value = "/ListOfOperation5")
	public String showDetail(@RequestParam("account")int account,Model model) {
		//Payment bank = new Payment();
		model.addAttribute("acc", account);
		return "ListOfOperation";
	}
//	@RequestMapping(value="/ListOfOperation2")
//	public String goHomePage2()
//	{
//		return "ListOfOperation";
//	}

	/*******************************************************/
//	@RequestMapping(value="/Tran")
//	public String diaplayHotelDetail(Model model)
//	{
//		Transaction tra = new Transaction();
//	   model.addAttribute("wallet", tra);
//		return "Transaction";
//	}

	@RequestMapping(value="/Tran")
	public String diaplayHotelDetail(@RequestParam("account")int account,Model model) throws BankException
	{
		ArrayList<Transaction> hList = service.transactionHistory(account);
		model.addAttribute("tList", hList);
		return "TransactionDisplay";
	}

	@RequestMapping(value="/ListOfOperation3")
	public String goHomePage3()
	{
		return "ListOfOperation";
	}
	
	
	/*******************************************/
	@RequestMapping(value="/Tranfer")
	public String diaplayTranferDetail(Model model)
	{
		Payment pay = new Payment();
	   model.addAttribute("wallet", pay);
		return "TransferMoney";
	}
	
	@RequestMapping(value="/TranferDetail")
	public String toTranferMoney(@ModelAttribute("wallet") Payment pay,Model model)throws BankException
	{
		//System.out.println("de"+pay);
		model.addAttribute("bal",pay.getBal());
		model.addAttribute("account", pay.getAccount());
		service.toAddMoney(pay.getBal(), pay.getAccount());
		service.toTransferMoney(pay.getBal(), Integer.parseInt(pay.getMobile()));
		String msg5 = "Money is Transfered";
		model.addAttribute("TransferMsg", msg5);
		return "ListOfOperation";
	}
	
}












































//@RequestMapping(value = "/Show")
//public String showDetail(Model model) {
//	Payment bank = new Payment();
//	model.addAttribute("wallet", bank);
//	return "ShowDetail";
//}

//@RequestMapping(value = "/ShowDetail1")
//public String showDetail(@ModelAttribute("wallet")Payment bank,Model model) throws BankException {
//	Payment pay=service.getPayment(bank.getAccount());
//	//WalletMoney money = service.getWalletinfo(bank.getAccount());
//	model.addAttribute("account", pay.getAccount());
//	model.addAttribute("ifsc", pay.getIfsc());
//	model.addAttribute("name", pay.getName());
//	model.addAttribute("mobile", pay.getMobile());
//	model.addAttribute("email", pay.getEmail());
//	model.addAttribute("accountBalance", pay.getBal());
//	//model.addAttribute("walletBalance", money.getBalance());
//	return "ShowDetail1";
//}

//@RequestMapping(value="/ListOfOperation4")
//public String goHomePage()
//{
//	return "ListOfOperation";
//}

//@RequestMapping(value = "/AddWalletMoney")
//public String addMoneyToWallet(@ModelAttribute("wallet") Payment bank, Model model) throws BankException {
//	System.out.println(bank);
//	service.toAddMoney(bank.getBal(), bank.getAccount());
//	WalletMoney money = new WalletMoney();
//	money.setAccount(bank.getAccount());
//	money.setBalance(bank.getBal());
//	service.addWalletBalance(money);
//	return "S";
//
//}

