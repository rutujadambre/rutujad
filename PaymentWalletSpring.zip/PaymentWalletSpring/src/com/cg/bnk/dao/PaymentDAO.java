package com.cg.bnk.dao;

import java.util.ArrayList;

import com.cg.bnk.bean.Payment;
import com.cg.bnk.bean.PaymentPassword;
import com.cg.bnk.bean.Transaction;
import com.cg.bnk.bean.WalletMoney;

public interface PaymentDAO {

	public Payment getPayment(int account);

	public Payment toAddMoney(int bal, int account, int transacAmount);

	public Payment toTransferMoney(int bal, int account, int transacAmount);

	public Payment addAccount(Payment pay);

	// public Payment toTransferFund(int acc1, int acc2, double bal)throws
	// BankException;

	public Payment checkAccount(int account, String ifsc, String name, String email);

	public PaymentPassword addPasswordAccount(PaymentPassword pass);

	public void addDetail(int acc, int bal);

	// public Transaction getDetail(int id)throws BankException;
	public ArrayList<Transaction> transactionHistory(int accountNo);

	public PaymentPassword getPasswordEmail(String password);

	public WalletMoney addWalletBalance(WalletMoney money);

	//public WalletMoney getWalletinfo(int account);
	public ArrayList<Integer> getWalletinfo(int account);
}