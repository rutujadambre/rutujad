package com.cg.bnk.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.bnk.bean.Payment;
import com.cg.bnk.bean.PaymentPassword;
import com.cg.bnk.bean.Transaction;
import com.cg.bnk.bean.WalletMoney;
import com.cg.bnk.dao.PaymentDAO;
import com.cg.bnk.dao.PaymentDAOImpl;
import com.cg.bnk.exception.BankException;
@Service
public class PaymentServiceImpl implements PaymentService{
	@Autowired
	PaymentDAO dao;
	

	public PaymentDAO getDao() {
		return dao;
	}


	public void setDao(PaymentDAO dao) {
		this.dao = dao;
	}


	public Payment getPayment(int account) throws BankException{
		// TODO Auto-generated method stub
		return dao.getPayment(account);
	}


	public Payment addAccount(Payment pay) throws BankException {
		// TODO Auto-generated method stub
		pay = dao.addAccount(pay);
		return pay;
	}


	@Override
	public Payment toAddMoney(int bal, int account) throws BankException {
		// TODO Auto-generated method stub
		Payment  pay = dao.getPayment(account);
		int money = pay.getBal()-bal;
		return dao.toAddMoney(money, account,bal);
	}


//	@Override
//	public Payment toTransferFund(int acc1, int acc2, double bal) throws BankException {
//		// TODO Auto-generated method stub
//		return dao.toTransferFund(acc1, acc2, bal);
//	}


	@Override
	public Payment checkAccount(int account,String ifsc,String name,String email) throws BankException {
		// TODO Auto-generated method stub
		return dao.checkAccount(account, ifsc, name, email);
		
	}


	@Override
	public PaymentPassword addPasswordAccount(PaymentPassword pass) throws BankException {
		// TODO Auto-generated method stub
		pass = dao.addPasswordAccount(pass);
		return pass;
	}


//	@Override
//	public Transaction addDetail(Transaction trans) throws BankException {
//		// TODO Auto-generated method stub
//		trans = dao.addDetail(trans);
//		return trans;
//	}


	@Override
	public ArrayList<Transaction> transactionHistory(int accountNo) throws BankException{
		// TODO Auto-generated method stub
		return dao.transactionHistory(accountNo);
	}


	@Override
	public Payment toTransferMoney(int bal, int account) throws BankException {
		// TODO Auto-generated method stub
		Payment  pay = dao.getPayment(account);
		int money = pay.getBal()+bal;
		return dao.toAddMoney(money, account,bal);
		//return null;
	}


	@Override
	public PaymentPassword getPasswordEmail(String password) throws BankException {
		// TODO Auto-generated method stub
		return dao.getPasswordEmail(password);
	}


	
	public WalletMoney addWalletBalance(WalletMoney money) throws BankException {
		// TODO Auto-generated method stub
		return dao.addWalletBalance(money);
	}


	@Override
	public ArrayList<Integer> getWalletinfo(int account) throws BankException {
		// TODO Auto-generated method stub
		return dao.getWalletinfo(account);
	}


//	@Override
//	public Payment checkAccount() {
//		// TODO Auto-generated method stub
//		return dao.checkAccount();
//	}


//	@Override
//	public Payment checkAccount(int account) {
//		// TODO Auto-generated method stub
//		return dao.checkAccount(account);
//	}

}
