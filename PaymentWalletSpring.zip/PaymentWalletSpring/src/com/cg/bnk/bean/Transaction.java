package com.cg.bnk.bean;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "transaction_JPA")
public class Transaction {

	@Id
	@Column(name = "transactionid", length = 20)
//	@GeneratedValue(strategy = GenerationType.AUTO)
	int transactionId;

	@Column(name = "accountno", length = 10)
	int accountNo;

	@Column(name = "amount", length = 10)
	int amount;

	@Column(name = "transactiondate")
	Date transactionDate;

	public int getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}

	public int getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}

	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}

	public Date getTransactionDate() {
		return transactionDate;
	}

	public void setTransactionDate(Date transactionDate) {
		this.transactionDate = transactionDate;
	}

	@Override
	public String toString() {
		return "Transaction [transactionId=" + transactionId + ", accountNo=" + accountNo + ", amount=" + amount
				+ ", transactionDate=" + transactionDate + "]";
	}

	
}
