package com.cg.demo.service;

import com.cg.demo.bean.Login;

public interface ILoginService {
	
	public Login validateUser(Login user);

}
