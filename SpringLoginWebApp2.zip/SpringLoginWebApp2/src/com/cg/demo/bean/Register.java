package com.cg.demo.bean;

import java.util.Arrays;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name="cg_userdetails")
public class Register {

	@Id
	@Column(name="user_name")
	private String uname;
	
	@Transient
	private String pwd;
	
	@Transient
	private String confirmPwd;
	
	@Column(name="first_name")
	private String firstName;
	
	@Column(name="last_name")
	private String lastName;
	
	@Transient
	private String skillSet[];
	
	@Column(name="user_skill")
	private String userSkill;
	
	@Column(name="user_email")
	private String userEmail;
	
	@Column(name="user_gender")
	private char userGender;
	
	@Column(name="user_city")
	private String userCity;

	public String getUname() {
		return uname;
	}

	public void setUname(String uname) {
		this.uname = uname;
	}

	public String getPwd() {
		return pwd;
	}

	public void setPwd(String pwd) {
		this.pwd = pwd;
	}

	public String getConfirmPwd() {
		return confirmPwd;
	}

	public void setConfirmPwd(String confirmPwd) {
		this.confirmPwd = confirmPwd;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String[] getSkillSet() {
		return skillSet;
	}

	public void setSkillSet(String[] skillSet) {
		this.skillSet = skillSet;
	}

	public String getUserSkill() {
		return userSkill;
	}

	public void setUserSkill(String userSkill) {
		this.userSkill = userSkill;
	}

	public String getUserEmail() {
		return userEmail;
	}

	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}

	public char getUserGender() {
		return userGender;
	}

	public void setUserGender(char userGender) {
		this.userGender = userGender;
	}

	public String getUserCity() {
		return userCity;
	}

	public void setUserCity(String userCity) {
		this.userCity = userCity;
	}

	@Override
	public String toString() {
		return "Register [uname=" + uname + ", pwd=" + pwd + ", confirmPwd=" + confirmPwd + ", firstName=" + firstName
				+ ", lastName=" + lastName + ", skillSet=" + Arrays.toString(skillSet) + ", userSkill=" + userSkill
				+ ", userEmail=" + userEmail + ", userGender=" + userGender + ", userCity=" + userCity + "]";
	}

	public Register(String uname, String pwd, String confirmPwd, String firstName, String lastName, String[] skillSet,
			String userSkill, String userEmail, char userGender, String userCity) {
		super();
		this.uname = uname;
		this.pwd = pwd;
		this.confirmPwd = confirmPwd;
		this.firstName = firstName;
		this.lastName = lastName;
		this.skillSet = skillSet;
		this.userSkill = userSkill;
		this.userEmail = userEmail;
		this.userGender = userGender;
		this.userCity = userCity;
	}

	public Register() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
}
