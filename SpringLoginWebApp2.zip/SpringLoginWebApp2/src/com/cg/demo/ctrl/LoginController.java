package com.cg.demo.ctrl;

import java.time.LocalDate;
import java.util.ArrayList;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.demo.bean.Login;
import com.cg.demo.bean.Register;
import com.cg.demo.service.ILoginService;

@Controller//marks a class as a Spring Web MVC controller
//@RequestMapping("/loginCtrl")//home pg=write<a href="loginCtrl/ShowLoginPage.obj">
public class LoginController {
	
	
//	@RequestMapping(value="/ShowLoginPage",method=RequestMethod.GET)
//	public String displayLoginPage()
//	{
//		return "Login";
//	}
	@Autowired
	ILoginService service = null;
	
	
	public ILoginService getService() {
		return service;
	}

	public void setService(ILoginService service) {
		this.service = service;
	}

	@RequestMapping(value="/ShowLoginPage",method=RequestMethod.GET)
	public String displayLoginPage(Model model)
	{
		Login lg = new Login();
		String msg = ""+LocalDate.now();
		model.addAttribute("msgObj",msg);
		model.addAttribute("loginObj",lg);
		return "Login";
	}
	
	/********************************/
	@RequestMapping(value="/ValidateUser",method=RequestMethod.POST)
	public String isUserValid(@ModelAttribute("loginObj") @Valid Login lgg,BindingResult result,Model model)
	{
		
		if(result.hasErrors())
		{
			System.out.println("yess errors!!!");
			return "Login";
		}
		else
		{
			Login user = service.validateUser(lgg);
			if(user!=null)
			{
				if(user.getPassword().equalsIgnoreCase(lgg.getPassword()))//user is existing and password is correct 
				{
					String msg = "Welcome UR valid :"+user.getPassword();
					model.addAttribute("MsgObj",msg);
					return "Success";
				}
				else
				{
					String msg = "Sorry UR Password is worng";
					model.addAttribute("MsgObj",msg);
					return "Login";
				}
			}
			else
			{
				Register reg = new Register();
				model.addAttribute("userObj",reg);
				
				ArrayList<String> cityList = new ArrayList<>();
				cityList.add("Pune");
				cityList.add("Noida");
				cityList.add("Nagpur");
				cityList.add("Mumbai");
				model.addAttribute("cList", cityList);
				
				ArrayList<String> skills = new ArrayList<>();
				skills.add("java");
				skills.add("Oracle");
				skills.add("BI");
				skills.add("HTML");
				model.addAttribute("skillList",skills);
				
				
				return "Registeration";
		
			}
		}
	}
	
	/*******************************************/
	@RequestMapping(value="InsertUserDetails")
	public String addUser(@ModelAttribute("userObj") Register reg,Model model,BindingResult result)
	{
		String sMsg = "Data is inserted";
		String eMsg = "Error is inserted";
//		model.addAttribute("MsgObj", sMsg);
//		model.addAttribute("UserDataObj", reg);
		
		Register rg = service.addUserdetails(reg);
		Login lg = service.addUser(new Login(reg.getUname(),reg.getPwd()));
		
		if(lg!=null && rg!=null)
		{
			model.addAttribute("MsgObj", sMsg);
		}
		else
		{
			model.addAttribute("MsgObj", eMsg);
		}
		
//		ArrayList<Register> uList = service.fetchAllUsers();
//		model.addAttribute("UserListObj", uList);
		
//		return "ListAllUser";
		return "redirect:/ShowAllUserDetails.obj";
	}
	
	/************************************/
	@RequestMapping(value="/DeleteUser")
	public String delUser(@RequestParam("unm") String name)	
	{
		service.delUser(name);
		return "redirect:/ShowAllUserDetails.obj";
	}
	
	/**************************************/
	@RequestMapping(value="/ShowAllUserDetails")
	public String dispAllUserDetails(Model model)
	{
		ArrayList<Register> uList = service.fetchAllUsers();
		model.addAttribute("UserListObj", uList);
		return "ListAllUser";
	}
}




















