package com.cg.demo.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.demo.bean.Login;
import com.cg.demo.bean.Register;
import com.cg.demo.dao.ILoginDao;


@Service
public class LoginServiceImpl implements ILoginService{
	@Autowired
	ILoginDao dao = null;
	
	public ILoginDao getDao() {
		return dao;
	}


	public void setDao(ILoginDao dao) {
		this.dao = dao;
	}


	@Override
	public Login validateUser(Login user) {
		// TODO Auto-generated method stub
		return dao.validateUser(user);
	}


	@Override
	public Register addUserdetails(Register reg) {
		// TODO Auto-generated method stub
		return dao.addUserdetails(reg);
	}


	@Override
	public Login addUser(Login log) {
		// TODO Auto-generated method stub
		return dao.addUser(log);
	}


	@Override
	public ArrayList<Register> fetchAllUsers() {
		// TODO Auto-generated method stub
		return dao.fetchAllUsers();
	}


	@Override
	public void delUser(String uname) {
		// TODO Auto-generated method stub
		dao.delUser(uname);
		
	}

}
