package com.cg.demo.dao;

import java.util.ArrayList;

import com.cg.demo.bean.Login;
import com.cg.demo.bean.Register;

public interface ILoginDao {
	
	public Login validateUser(Login user);
	
	public Register addUserdetails(Register reg);
	
	public Login addUser(Login log);
	
	public ArrayList<Register> fetchAllUsers();
	
	public void delUser(String uname);

}
