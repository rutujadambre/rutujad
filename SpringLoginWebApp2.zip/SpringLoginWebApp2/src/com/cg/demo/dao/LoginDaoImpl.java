package com.cg.demo.dao;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cg.demo.bean.Login;
import com.cg.demo.bean.Register;

@Repository
@Transactional
public class LoginDaoImpl implements ILoginDao{

	@PersistenceContext
	EntityManager entityMgr = null;
	
	public EntityManager getEntityMgr() {
		return entityMgr;
	}

	public void setEntityMgr(EntityManager entityMgr) {
		this.entityMgr = entityMgr;
	}

	@Override
	public Login validateUser(Login user) {
		// TODO Auto-generated method stub
		Login usr = entityMgr.find(Login.class, user.getUserName());
		return usr;

	}

	@Override
	public Register addUserdetails(Register reg) {
		// TODO Auto-generated method stub
		entityMgr.persist(reg);
		Register obj = entityMgr.find(Register.class, reg.getUname());
		return obj;
	}

	@Override
	public Login addUser(Login log) {
		// TODO Auto-generated method stub
		entityMgr.persist(log);
		Login obj = entityMgr.find(Login.class, log.getUserName());
		return obj;
	}

	@Override
	public ArrayList<Register> fetchAllUsers() {
		// TODO Auto-generated method stub
		String qry = "select reg from Register reg";
		TypedQuery<Register> tq = entityMgr.createQuery(qry,Register.class);
		ArrayList<Register> uList = (ArrayList<Register>) tq.getResultList();
		return uList;
	}

	@Override
	public void delUser(String uname) {
		// TODO Auto-generated method stub
		Register reg = entityMgr.find(Register.class, uname);
		Login log = entityMgr.find(Login.class, uname);
		entityMgr.remove(reg);
		entityMgr.remove(log);
	}

}
