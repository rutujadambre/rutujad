package com.cg.lab.dao;

import com.cg.lab.bean.QueryMaster;

public interface IQueryMasterDAO {

	public QueryMaster fetchById(int id);
	
	public QueryMaster modifyById(QueryMaster q);

	public QueryMaster validateId(QueryMaster q);
}
