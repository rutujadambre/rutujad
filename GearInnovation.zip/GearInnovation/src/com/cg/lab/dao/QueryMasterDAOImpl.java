package com.cg.lab.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.lab.bean.QueryMaster;

@Repository
@Transactional
public class QueryMasterDAOImpl implements IQueryMasterDAO{

	@PersistenceContext
	EntityManager emMgr = null;

	public EntityManager getEmMgr() {
		return emMgr;
	}

	public void setEmMgr(EntityManager emMgr) {
		this.emMgr = emMgr;
	}

	@Override
	public QueryMaster fetchById(int id) {
		// TODO Auto-generated method stub
		QueryMaster qry = emMgr.find(QueryMaster.class, id);
		return qry;
	}

	@Override
	public QueryMaster modifyById(QueryMaster q) {
		// TODO Auto-generated method stub
		QueryMaster q1 = emMgr.find(QueryMaster.class, q.getQueryId());
		q1.setSolution(q.getSolution());
		q1.setSolutionGiven(q.getSolutionGiven());
		return q1;
	}

	@Override
	public QueryMaster validateId(QueryMaster q) {
		// TODO Auto-generated method stub
		QueryMaster q1 = emMgr.find(QueryMaster.class, q.getQueryId());
		return q1;
	}
	
	
}
