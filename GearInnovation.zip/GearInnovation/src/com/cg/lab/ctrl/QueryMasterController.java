package com.cg.lab.ctrl;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.lab.bean.QueryMaster;
import com.cg.lab.service.IQueryMasterService;

@Controller
public class QueryMasterController {
	
	@Autowired
	IQueryMasterService service = null;

	public IQueryMasterService getService() {
		return service;
	}

	public void setService(IQueryMasterService service) {
		this.service = service;
	}
	
	@RequestMapping(value="/ShowPage")
	public String displayGearTechnicalPage(Model model)
	{
		QueryMaster q = new QueryMaster();
		model.addAttribute("loginObj",q);
		return "GearTechnicalForum";
	}
	
	@RequestMapping(value="/GearForum")
	public String technicalForumControl(@ModelAttribute("loginObj") QueryMaster q,Model model)
	{
		if(q.getQueryId()<5 && q.getQueryId()>0)
		{
			QueryMaster q1 = service.fetchById(q.getQueryId());
			model.addAttribute("loginObj", q1);
			//model.addAttribute("msgObj",q.getQueryId());
			ArrayList<String> sol = new ArrayList<>();
			sol.add("Uma");
			sol.add("Rahul");
			sol.add("Kavita");
			sol.add("Hema");
			model.addAttribute("sList", sol);
			return "GearTechnicalForum2";
		}
		else
		{
			int i = q.getQueryId();
			model.addAttribute("msgObj1",i);
			return "Failure";
		}
		
//		ArrayList<String> sol = new ArrayList<>();
//		sol.add("Uma");
//		sol.add("Rahul");
//		sol.add("Kavita");
//		sol.add("Hema");
//		model.addAttribute("sList", sol);
//		return "GearTechnicalForum2";
	}
	
	@RequestMapping(value="/updateDatabase")
	public String updateForum(@ModelAttribute("loginObj") QueryMaster q,Model model)
	{
		service.modifyById(q);
		model.addAttribute("loginObj", q);
		
		QueryMaster qry = service.validateId(q);
		model.addAttribute("msgObj",q.getQueryId());
		return "Success";
	}
	
	@RequestMapping(value="/GearTechnicalForum1")
	public String dispHref(@ModelAttribute("loginObj") QueryMaster q,Model model)
	{
		model.addAttribute("loginObj", q);
		return "GearTechnicalForum";
	}
}
