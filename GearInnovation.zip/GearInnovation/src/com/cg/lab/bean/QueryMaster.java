package com.cg.lab.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="query_master")
public class QueryMaster {

	@Id
	@Column(name="query_id")
	private int queryId;
	
	@Column(name="technology")
	private String technology;
	
	@Column(name="query_raised")
	private String queryRaised;
	
	@Column(name="query")
	private String query;
	
	@Column(name="solution")
	private String solution;
	
	@Column(name="solution_given")
	private String solutionGiven;

	public int getQueryId() {
		return queryId;
	}

	public void setQueryId(int queryId) {
		this.queryId = queryId;
	}

	public String getTechnology() {
		return technology;
	}

	public void setTechnology(String technology) {
		this.technology = technology;
	}

	public String getQueryRaised() {
		return queryRaised;
	}

	public void setQueryRaised(String queryRaised) {
		this.queryRaised = queryRaised;
	}

	public String getQuery() {
		return query;
	}

	public void setQuery(String query) {
		this.query = query;
	}

	public String getSolution() {
		return solution;
	}

	public void setSolution(String solution) {
		this.solution = solution;
	}

	public String getSolutionGiven() {
		return solutionGiven;
	}

	public void setSolutionGiven(String solutionGiven) {
		this.solutionGiven = solutionGiven;
	}

	@Override
	public String toString() {
		return "QueryMaster [queryId=" + queryId + ", technology=" + technology + ", queryRaised=" + queryRaised
				+ ", query=" + query + ", solution=" + solution + ", solutionGiven=" + solutionGiven + "]";
	}

	public QueryMaster(int queryId, String technology, String queryRaised, String query, String solution,
			String solutionGiven) {
		super();
		this.queryId = queryId;
		this.technology = technology;
		this.queryRaised = queryRaised;
		this.query = query;
		this.solution = solution;
		this.solutionGiven = solutionGiven;
	}

	public QueryMaster() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
}
