package com.cg.lab.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.lab.bean.QueryMaster;
import com.cg.lab.dao.IQueryMasterDAO;

@Service
public class QueryMasterServiceImpl implements IQueryMasterService{
	
	@Autowired
	IQueryMasterDAO dao = null;

	public IQueryMasterDAO getDao() {
		return dao;
	}

	public void setDao(IQueryMasterDAO dao) {
		this.dao = dao;
	}

	@Override
	public QueryMaster fetchById(int id) {
		// TODO Auto-generated method stub
		return dao.fetchById(id);
	}

	@Override
	public QueryMaster modifyById(QueryMaster q) {
		// TODO Auto-generated method stub
		return dao.modifyById(q);
	}

	@Override
	public QueryMaster validateId(QueryMaster q) {
		// TODO Auto-generated method stub
		return dao.validateId(q);
	}
	
	
}
