package com.cg.lab.service;

import com.cg.lab.bean.QueryMaster;

public interface IQueryMasterService {

	public QueryMaster fetchById(int id);
	
	public QueryMaster modifyById(QueryMaster q);

	public QueryMaster validateId(QueryMaster q);
}
