package com.cg.demo.ctrl;

import java.time.LocalDate;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping(value="/helloCtrl")
public class HelloController {
	
	@RequestMapping(value="/ShowHomepage")
//	public ModelAndView displayHomePage()
//	{
//		String today = ""+LocalDate.now();
//		return new ModelAndView("Home","todayObj",today);//name from web-inf/jsp
//	}
	public String displayHomePage(Model model)
	{
		String today = ""+LocalDate.now();
		model.addAttribute("todayObj", today);
		return "Home";//name from web-inf/jsp
	}
	
	@RequestMapping(value="ShowGreetMePage")
	public String displayGreetPage()
	{
		return "GreetMe";
	}
	
//	@RequestMapping(value="/ShowNamepage")
//	public ModelAndView displayNamePage()
//	{
//		String a ="Rutuja";
//		return new ModelAndView("Home","gfg",a);//name from web-inf/jsp
//	}
}
