package com.cg.lab.dao;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cg.lab.bean.Login;
import com.cg.lab.bean.Trainee;

import javafx.scene.shape.TriangleMesh;

@Repository
@Transactional
public class TraineeDaoImpl implements ITraineeDao{

	@PersistenceContext
	EntityManager entityMgr = null;
	
	public EntityManager getEntityMgr() {
		return entityMgr;
	}



	public void setEntityMgr(EntityManager entityMgr) {
		this.entityMgr = entityMgr;
	}



	@Override
	public Login validateUser(Login user) {
		// TODO Auto-generated method stub
		Login usr = entityMgr.find(Login.class, user.getUserName());
		return usr;
	}



	@Override
	public Trainee addTraineeDetail(Trainee id) {
		// TODO Auto-generated method stub
		entityMgr.persist(id);
		Trainee obj = entityMgr.find(Trainee.class, id.getTraineeId());
		return obj;
	}



	@Override
	public ArrayList<Trainee> fetchAllUsers() {
		// TODO Auto-generated method stub
		String qry = "select tr from Trainee tr";
		TypedQuery<Trainee> tq = entityMgr.createQuery(qry,Trainee.class);
		ArrayList<Trainee> uList = (ArrayList<Trainee>) tq.getResultList();
		return uList;
	}



	@Override
	public Trainee deleteTrainee(int id) {
		// TODO Auto-generated method stub
		Trainee tr = entityMgr.find(Trainee.class, id);
		entityMgr.remove(tr);
		return tr;
	}



	@Override
	public Trainee fetchUsers(int id) {
		// TODO Auto-generated method stub
		Trainee tr = entityMgr.find(Trainee.class, id);
		return tr;
	}



	@Override
	public Trainee modifyById(Trainee tr) {
		// TODO Auto-generated method stub
		Trainee tr1 = entityMgr.find(Trainee.class, tr.getTraineeId());
//		tr.setTraineeId(traineeId);
		tr1.setTraineeDomain(tr.getTraineeDomain());
		tr1.setTraineeLocation(tr.getTraineeLocation());
		tr1.setTraineeName(tr.getTraineeName());
		entityMgr.merge(tr);
		return tr;
	}






}
