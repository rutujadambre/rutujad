package com.cg.lab.dao;

import java.util.ArrayList;

import com.cg.lab.bean.Login;
import com.cg.lab.bean.Trainee;

public interface ITraineeDao {
	
	public Login validateUser(Login user);
	
	public Trainee addTraineeDetail(Trainee id);
	
	public Trainee deleteTrainee(int id);

	public Trainee fetchUsers(int id);
	
	public ArrayList<Trainee> fetchAllUsers();
	
	//public Trainee modifyById(int id,String name,String location,String domain);
	public Trainee modifyById(Trainee tr);

}
