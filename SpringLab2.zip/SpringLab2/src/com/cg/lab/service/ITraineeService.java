package com.cg.lab.service;

import java.util.ArrayList;

import com.cg.lab.bean.Login;
import com.cg.lab.bean.Trainee;

public interface ITraineeService {
	
	public Login validateUser(Login user);

	public Trainee addTraineeDetail(Trainee id);

	public Trainee deleteTrainee(int id);
	
	public Trainee fetchUsers(int id);
	
	public ArrayList<Trainee> fetchAllUsers();

	public Trainee modifyById(Trainee tr);
}
