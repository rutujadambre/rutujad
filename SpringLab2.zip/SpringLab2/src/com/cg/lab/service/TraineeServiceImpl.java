package com.cg.lab.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.lab.bean.Login;
import com.cg.lab.bean.Trainee;
import com.cg.lab.dao.ITraineeDao;

@Service
public class TraineeServiceImpl implements ITraineeService{
	@Autowired
	ITraineeDao dao = null;
	
	public ITraineeDao getDao() {
		return dao;
	}

	public void setDao(ITraineeDao dao) {
		this.dao = dao;
	}

	@Override
	public Login validateUser(Login user) {
		// TODO Auto-generated method stub
		return dao.validateUser(user);
	}

	@Override
	public Trainee addTraineeDetail(Trainee id) {
		// TODO Auto-generated method stub
		return dao.addTraineeDetail(id);
	}

	@Override
	public ArrayList<Trainee> fetchAllUsers() {
		// TODO Auto-generated method stub
		return dao.fetchAllUsers();
	}

	@Override
	public Trainee deleteTrainee(int id) {
		// TODO Auto-generated method stub
		return dao.deleteTrainee(id);
	}

	@Override
	public Trainee fetchUsers(int id) {
		// TODO Auto-generated method stub
		return dao.fetchUsers(id);
	}

	@Override
	public Trainee modifyById(Trainee tr) {
		// TODO Auto-generated method stub
		return dao.modifyById(tr);
	}



}
