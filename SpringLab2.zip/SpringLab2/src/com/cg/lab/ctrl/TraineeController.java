package com.cg.lab.ctrl;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.lab.bean.Login;
import com.cg.lab.bean.Trainee;
import com.cg.lab.service.ITraineeService;

@Controller
public class TraineeController {
	
	@Autowired
	ITraineeService service = null;

	public ITraineeService getService() {
		return service;
	}

	public void setService(ITraineeService service) {
		this.service = service;
	}
	
	@RequestMapping(value="/ShowLoginPage")
	public String displayLoginPage(Model model)
	{
		Login lg = new Login();
		model.addAttribute("loginObj",lg);
		return "Login";
	}
	
	@RequestMapping(value="/validateUser")
	public String isUserValid(@ModelAttribute("loginObj") Login llg,Model model)
	{
		Login user = service.validateUser(llg);
		if(user!=null)
		{
			if(user.getPassword().equalsIgnoreCase(llg.getPassword()))
			{
				return "TraineeMngSystem";
			}
			else
			{
				String msg = "Sorry Wrong Password";
				model.addAttribute("msgObj",msg);
				return "Login";
			}
		}
		else
		{
			String msg = "You Are Invalid User";
			model.addAttribute("msgObj1",msg);
			return "Login";
		}
	}
	
	@RequestMapping(value="/AddATrainee")
	//@RequestMapping(value="/addTraineeDetails")
	public String addATrainee(@ModelAttribute("add") Trainee t, Model model)
	{
		//Trainee t = new Trainee();
		model.addAttribute("add", t);
		
		ArrayList<String> locationList = new ArrayList<>();
		locationList.add("Chennai");
		locationList.add("Bangalore");
		locationList.add("Pune");
		locationList.add("Mumbai");
		model.addAttribute("lList",locationList);
		
		ArrayList<String> domainList = new ArrayList<>();
		domainList.add("JEE");
		domainList.add("Oracle");
		domainList.add("BI");
		domainList.add("HTML");
		model.addAttribute("dList",domainList);
		
		return "AddATrainees";
	}
	
	@RequestMapping(value="/addTraineeDetails")
	public String addData(@ModelAttribute("add") Trainee tr,Model model)
	{
		//model.addAttribute("addedTrainee", tr);
		service.addTraineeDetail(tr);
		return "TraineeMngSystem";
	}
/*******************Delete Trainee*************************/	
	@RequestMapping(value="/DeleteATrinee")
	public String deleteATrainee(Model model)
	{
		//tr = service.deleteTrainee(tr);
		Trainee tr = new Trainee();
		model.addAttribute("deleteData",tr);
		return "DeleteATrainees";
	}
	
	@RequestMapping(value="/ShowDeleteTrainee")
	public String deleteDetail(@ModelAttribute("deleteData") Trainee tr1,Model model)
	{
		Trainee trg = service.fetchUsers(tr1.getTraineeId());
		model.addAttribute("TrgDetailObj", trg);
		return "DeleteATrainees1";
	}
	
	@RequestMapping(value="/DeleteUser")
	public String deleteData(@RequestParam("unm") int id)
	{
		service.deleteTrainee(id);
		return "TraineeMngSystem";
	}
	
	
	/*********************Modify Trainee*******************/	
	@RequestMapping(value="/ModifyATrainee")
	public String modifyATrainee(Model model)
	{
		Trainee tr = new Trainee();
		model.addAttribute("modifyData",tr);
		return "ModifyATrianees";
	}
	
	@RequestMapping(value="/ShowModifyTrainee")
	public String getTrainee(@ModelAttribute(value="modifyData") Trainee tr,Model model)
	{
		//Trainee tr = new Trainee();
		Trainee trg = service.fetchUsers(tr.getTraineeId());
		model.addAttribute("modifyData", trg);
		return "ModifyATrianees1";
	}
	@RequestMapping(value="/AfterModifyTrainee")
	public String modifyData(@ModelAttribute(value="modifyData") Trainee tr, Model model)
	{
//		int i = tr.getTraineeId();
//		String n = tr.getTraineeName();
//		String l = tr.getTraineeLocation();
//		String d = tr.getTraineeDomain();
//		service.modifyById(i, n, l, d);
		service.modifyById(tr);
		model.addAttribute("modifyData",tr);
		
		return "TraineeMngSystem";
	}
/******************Retrive Trainee**********************/
	@RequestMapping(value="/RetriveATrainee")
	public String retriveATrainee(Model model)
	{
		//t = service.fetchUsers(id);
		Trainee tr = new Trainee();
		model.addAttribute("retrieveOperation",tr);
		return "RetriveATrainees";
	}
	
	@RequestMapping(value="/ShowRetrieveTrainee")
	public String retrieveDetail(@ModelAttribute("retrieveOperation") Trainee tr2,Model model)
	{
		Trainee trg1 = service.fetchUsers(tr2.getTraineeId());
		model.addAttribute("TrgDetailObj", trg1);
		return "RetriveATrainees1";
	}
	
	/******************Retrive All Trainee************************/

	@RequestMapping(value="/RetriveAllTrainee")
	public String displayAllTrainees(@ModelAttribute("retriveAllData") Trainee tr,Model model)
	{
		ArrayList<Trainee> uList = service.fetchAllUsers();
		model.addAttribute("traineeList", uList);
		return "RetriveAllTrainees";
	}
}


//@RequestMapping(value="/DeleteUser")
//public String delUser(@RequestParam("unm") String name)	
//{
//	service.delUser(name);
//	return "redirect:/ShowAllUserDetails.obj";
//}











