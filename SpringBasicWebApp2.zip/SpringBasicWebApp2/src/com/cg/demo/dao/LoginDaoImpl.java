package com.cg.demo.dao;

import org.springframework.stereotype.Repository;

import com.cg.demo.bean.Login;

@Repository
public class LoginDaoImpl implements ILoginDao{

	@Override
	public Login validateUser(Login user) {
		// TODO Auto-generated method stub
		String un = user.getUserName();
		String pw = user.getPassword();
		if(un.equalsIgnoreCase("cg") && pw.equalsIgnoreCase("cg"))
		{
			return user;
		}
		else
		{
			return null;
		}
		
	}
	
	

}
