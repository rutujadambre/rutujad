package com.cg.demo.ctrl;

import java.time.LocalDate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cg.demo.bean.Login;
import com.cg.demo.service.ILoginService;

@Controller
//@RequestMapping("/loginCtrl")//home pg=write<a href="loginCtrl/ShowLoginPage.obj">
public class LoginController {
	
	
//	@RequestMapping(value="/ShowLoginPage",method=RequestMethod.GET)
//	public String displayLoginPage()
//	{
//		return "Login";
//	}
	@Autowired
	ILoginService service = null;
	
	
	public ILoginService getService() {
		return service;
	}

	public void setService(ILoginService service) {
		this.service = service;
	}

	@RequestMapping(value="/ShowLoginPage",method=RequestMethod.GET)
	public String displayLoginPage(Model model)
	{
		Login lg = new Login();
		String msg = ""+LocalDate.now();
		model.addAttribute("msgObj",msg);
		model.addAttribute("loginObj",lg);
		return "Login";
	}
	
	/********************************/
	@RequestMapping(value="/ValidateUser",method=RequestMethod.POST)
	public String isUserValid(@ModelAttribute("loginObj") Login lgg)
	{
		Login user = service.validateUser(lgg);
		if(user!=null)
		{
			return "Success";
		}
		else
		{
	
			return "Failure";
	
		}
	}	
}
