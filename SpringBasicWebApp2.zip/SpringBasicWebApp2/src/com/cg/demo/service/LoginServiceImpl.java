package com.cg.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.demo.bean.Login;
import com.cg.demo.dao.ILoginDao;


@Service
public class LoginServiceImpl implements ILoginService{
	
	ILoginDao dao = null;
	
	@Autowired
	public ILoginDao getDao() {
		return dao;
	}


	public void setDao(ILoginDao dao) {
		this.dao = dao;
	}


	@Override
	public Login validateUser(Login user) {
		// TODO Auto-generated method stub
		return dao.validateUser(user);
	}

}
