package com.cg.lab.ctrl;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.lab.bean.Client;
import com.cg.lab.service.IBookingService;

@Controller
public class BookingController {

	@Autowired
	IBookingService service = null;

	public IBookingService getService() {
		return service;
	}

	public void setService(IBookingService service) {
		this.service = service;
	}
	
/******************Hotel Detail************************/	
	@RequestMapping(value="/ShowFirstPage")
	public String diaplayHotelDetail(@ModelAttribute("hotelDetail") Client hotel,Model model)
	{
		ArrayList<Client> hList = service.fetchAllHotel();
		model.addAttribute("hotelList", hList);
		return "HotelDetails";
	}

	
/********************Booking Detail****************************/
	@RequestMapping(value="/fetchHotel")
	public String bookingConfirmation(@RequestParam("fh") String name ,Client client,Model model)
	{
		
		service.fetchByHotelName(name);
		model.addAttribute("msgObj", name);
		return "BookingConfirmation";
	}
	
	
/********************Hotel Detail Page*************************/	
	@RequestMapping(value="/homeHotel")
	public String goHomePage()
	{
		return "redirect:/ShowFirstPage.obj";
	}
}
