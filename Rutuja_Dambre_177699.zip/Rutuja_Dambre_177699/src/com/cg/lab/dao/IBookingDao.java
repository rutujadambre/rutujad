package com.cg.lab.dao;

import java.util.ArrayList;

import com.cg.lab.bean.Client;

public interface IBookingDao {
	
	public ArrayList<Client> fetchAllHotel();

	public ArrayList<Client> fetchByHotelName(String name);

}
