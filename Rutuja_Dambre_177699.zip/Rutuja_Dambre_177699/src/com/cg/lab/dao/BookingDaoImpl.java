package com.cg.lab.dao;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.lab.bean.Client;

@Repository
@Transactional
public class BookingDaoImpl implements IBookingDao{

	@PersistenceContext
	EntityManager entityMgr = null;

	public EntityManager getEntityMgr() {
		return entityMgr;
	}

	public void setEntityMgr(EntityManager entityMgr) {
		this.entityMgr = entityMgr;
	}

	@Override
	public ArrayList<Client> fetchAllHotel() {
		// TODO Auto-generated method stub
		String qry = "select hotel from Client hotel";
		TypedQuery<Client> tq = entityMgr.createQuery(qry, Client.class);
		ArrayList<Client> hList = (ArrayList<Client>) tq.getResultList();
		return hList;
	}

	@Override
	public ArrayList<Client> fetchByHotelName(String name) {
		// TODO Auto-generated method stub
		String qry = "select hotel from Client hotel where hotelName='"+name+"'";
		TypedQuery<Client> tq = entityMgr.createQuery(qry, Client.class);
		ArrayList<Client> hList = (ArrayList<Client>) tq.getResultList();
		return hList;
	}

	
	
}
