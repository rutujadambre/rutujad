package com.cg.lab.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="hoteldetails")
public class Client {
	
	@Id
	@Column(name="id")
	private int hotelId;
	
	@Column(name="name")
	private String hotelName;
	
	@Column(name="rating")
	private String hotelRating;
	
	@Column(name="rate")
	private int hotelRate;
	
	@Column(name="availablerooms")
	private int availableRooms;

	public int getHotelId() {
		return hotelId;
	}

	public void setHotelId(int hotelId) {
		this.hotelId = hotelId;
	}

	public String getHotelName() {
		return hotelName;
	}

	public void setHotelName(String hotelName) {
		this.hotelName = hotelName;
	}

	public String getHotelRating() {
		return hotelRating;
	}

	public void setHotelRating(String hotelRating) {
		this.hotelRating = hotelRating;
	}

	public int getHotelRate() {
		return hotelRate;
	}

	public void setHotelRate(int hotelRate) {
		this.hotelRate = hotelRate;
	}

	public int getAvailableRooms() {
		return availableRooms;
	}

	public void setAvailableRooms(int availableRooms) {
		this.availableRooms = availableRooms;
	}

	@Override
	public String toString() {
		return "HotelDetails [hotelId=" + hotelId + ", hotelName=" + hotelName + ", hotelRating=" + hotelRating
				+ ", hotelRate=" + hotelRate + ", availableRooms=" + availableRooms + "]";
	}

	public Client(int hotelId, String hotelName, String hotelRating, int hotelRate, int availableRooms) {
		super();
		this.hotelId = hotelId;
		this.hotelName = hotelName;
		this.hotelRating = hotelRating;
		this.hotelRate = hotelRate;
		this.availableRooms = availableRooms;
	}

	public Client() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	

}
