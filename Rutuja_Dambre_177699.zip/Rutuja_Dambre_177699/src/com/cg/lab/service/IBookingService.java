package com.cg.lab.service;

import java.util.ArrayList;

import com.cg.lab.bean.Client;

public interface IBookingService {

	public ArrayList<Client> fetchAllHotel();
	
	public ArrayList<Client> fetchByHotelName(String name);
}
