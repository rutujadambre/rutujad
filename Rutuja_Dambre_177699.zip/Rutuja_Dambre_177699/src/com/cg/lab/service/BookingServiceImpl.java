package com.cg.lab.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.lab.bean.Client;
import com.cg.lab.dao.IBookingDao;

@Service
public class BookingServiceImpl implements IBookingService{

	@Autowired
	IBookingDao dao = null;

	public IBookingDao getDao() {
		return dao;
	}

	public void setDao(IBookingDao dao) {
		this.dao = dao;
	}

	@Override
	public ArrayList<Client> fetchAllHotel() {
		// TODO Auto-generated method stub
		return dao.fetchAllHotel();
	}

	@Override
	public ArrayList<Client> fetchByHotelName(String name) {
		// TODO Auto-generated method stub
		return dao.fetchByHotelName(name);
	}
	
}
